
--------------------------------
-- @module EaseCubicActionIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseCubicActionIn#EaseCubicActionIn ret (return value: cc.EaseCubicActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] clone 
-- @param self
-- @return EaseCubicActionIn#EaseCubicActionIn ret (return value: cc.EaseCubicActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] update 
-- @param self
-- @param #float time
-- @return EaseCubicActionIn#EaseCubicActionIn self (return value: cc.EaseCubicActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] EaseCubicActionIn 
-- @param self
-- @return EaseCubicActionIn#EaseCubicActionIn self (return value: cc.EaseCubicActionIn)
        
return nil
