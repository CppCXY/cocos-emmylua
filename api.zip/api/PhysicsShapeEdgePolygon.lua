
--------------------------------
-- @module PhysicsShapeEdgePolygon
-- @extend PhysicsShape
-- @parent_module cc

--------------------------------
-- Get this polygon's points array count.<br>
-- return An integer number.
-- @function [parent=#PhysicsShapeEdgePolygon] getPointsCount 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get this polygon's center position.<br>
-- return A Vec2 object.
-- @function [parent=#PhysicsShapeEdgePolygon] getCenter 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
return nil
