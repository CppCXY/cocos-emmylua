
--------------------------------
-- @module TransitionMoveInL
-- @extend TransitionScene,TransitionEaseScene
-- @parent_module cc

--------------------------------
--  Returns the action that will be performed. <br>
-- return The action that will be performed.
-- @function [parent=#TransitionMoveInL] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionMoveInL] easeActionWithAction 
-- @param self
-- @param #cc.ActionInterval action
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
--  Creates a transition with duration and incoming scene.<br>
-- param t Duration time, in seconds.<br>
-- param scene A given scene.<br>
-- return A autoreleased TransitionMoveInL object.
-- @function [parent=#TransitionMoveInL] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionMoveInL#TransitionMoveInL ret (return value: cc.TransitionMoveInL)
        
--------------------------------
-- 
-- @function [parent=#TransitionMoveInL] TransitionMoveInL 
-- @param self
-- @return TransitionMoveInL#TransitionMoveInL self (return value: cc.TransitionMoveInL)
        
return nil
