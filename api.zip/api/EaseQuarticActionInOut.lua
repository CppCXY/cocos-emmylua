
--------------------------------
-- @module EaseQuarticActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuarticActionInOut#EaseQuarticActionInOut ret (return value: cc.EaseQuarticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] clone 
-- @param self
-- @return EaseQuarticActionInOut#EaseQuarticActionInOut ret (return value: cc.EaseQuarticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] update 
-- @param self
-- @param #float time
-- @return EaseQuarticActionInOut#EaseQuarticActionInOut self (return value: cc.EaseQuarticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] EaseQuarticActionInOut 
-- @param self
-- @return EaseQuarticActionInOut#EaseQuarticActionInOut self (return value: cc.EaseQuarticActionInOut)
        
return nil
