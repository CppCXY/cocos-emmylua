
--------------------------------
-- @module AnimationData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#AnimationData] getMovement 
-- @param self
-- @param #string movementName
-- @return MovementData#MovementData ret (return value: ccs.MovementData)
        
--------------------------------
-- 
-- @function [parent=#AnimationData] getMovementCount 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#AnimationData] addMovement 
-- @param self
-- @param #ccs.MovementData movData
-- @return AnimationData#AnimationData self (return value: ccs.AnimationData)
        
--------------------------------
-- 
-- @function [parent=#AnimationData] create 
-- @param self
-- @return AnimationData#AnimationData ret (return value: ccs.AnimationData)
        
--------------------------------
-- js ctor
-- @function [parent=#AnimationData] AnimationData 
-- @param self
-- @return AnimationData#AnimationData self (return value: ccs.AnimationData)
        
return nil
