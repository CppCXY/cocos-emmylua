
--------------------------------
-- @module ScaleFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ScaleFrame] setScaleY 
-- @param self
-- @param #float scaleY
-- @return ScaleFrame#ScaleFrame self (return value: ccs.ScaleFrame)
        
--------------------------------
-- 
-- @function [parent=#ScaleFrame] setScaleX 
-- @param self
-- @param #float scaleX
-- @return ScaleFrame#ScaleFrame self (return value: ccs.ScaleFrame)
        
--------------------------------
-- 
-- @function [parent=#ScaleFrame] getScaleY 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#ScaleFrame] getScaleX 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#ScaleFrame] setScale 
-- @param self
-- @param #float scale
-- @return ScaleFrame#ScaleFrame self (return value: ccs.ScaleFrame)
        
--------------------------------
-- 
-- @function [parent=#ScaleFrame] create 
-- @param self
-- @return ScaleFrame#ScaleFrame ret (return value: ccs.ScaleFrame)
        
--------------------------------
-- 
-- @function [parent=#ScaleFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#ScaleFrame] ScaleFrame 
-- @param self
-- @return ScaleFrame#ScaleFrame self (return value: ccs.ScaleFrame)
        
return nil
