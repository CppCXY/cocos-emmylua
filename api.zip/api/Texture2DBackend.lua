
--------------------------------
-- @module Texture2DBackend
-- @extend TextureBackend
-- @parent_module ccb

--------------------------------
-- Get texture height.<br>
-- return Texture height.
-- @function [parent=#Texture2DBackend] getHeight 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- Get texture width.<br>
-- return Texture width.
-- @function [parent=#Texture2DBackend] getWidth 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- Update a two-dimensional texture image<br>
-- param data Specifies a pointer to the image data in memory.<br>
-- param width Specifies the width of the texture image.<br>
-- param height Specifies the height of the texture image.<br>
-- param level Specifies the level-of-detail number. Level 0 is the base image level. Level n is the nth mipmap reduction image.
-- @function [parent=#Texture2DBackend] updateData 
-- @param self
-- @param #unsigned char data
-- @param #unsigned int width
-- @param #unsigned int height
-- @param #unsigned int level
-- @return backend::Texture2DBackend#backend::Texture2DBackend self (return value: cc.backend::Texture2DBackend)
        
--------------------------------
-- Update a two-dimensional texture image in a compressed format<br>
-- param data Specifies a pointer to the compressed image data in memory.<br>
-- param width Specifies the width of the texture image.<br>
-- param height Specifies the height of the texture image.<br>
-- param dataLen Specifies the totoal size of compressed image in bytes.<br>
-- param level Specifies the level-of-detail number. Level 0 is the base image level. Level n is the nth mipmap reduction image.
-- @function [parent=#Texture2DBackend] updateCompressedData 
-- @param self
-- @param #unsigned char data
-- @param #unsigned int width
-- @param #unsigned int height
-- @param #unsigned int dataLen
-- @param #unsigned int level
-- @return backend::Texture2DBackend#backend::Texture2DBackend self (return value: cc.backend::Texture2DBackend)
        
--------------------------------
-- Update a two-dimensional texture subimage<br>
-- param xoffset Specifies a texel offset in the x direction within the texture array.<br>
-- param yoffset Specifies a texel offset in the y direction within the texture array.<br>
-- param width Specifies the width of the texture subimage.<br>
-- param height Specifies the height of the texture subimage.<br>
-- param level Specifies the level-of-detail number. Level 0 is the base image level. Level n is the nth mipmap reduction image.<br>
-- param data Specifies a pointer to the image data in memory.
-- @function [parent=#Texture2DBackend] updateSubData 
-- @param self
-- @param #unsigned int xoffset
-- @param #unsigned int yoffset
-- @param #unsigned int width
-- @param #unsigned int height
-- @param #unsigned int level
-- @param #unsigned char data
-- @return backend::Texture2DBackend#backend::Texture2DBackend self (return value: cc.backend::Texture2DBackend)
        
--------------------------------
-- Update a two-dimensional texture subimage in a compressed format<br>
-- param xoffset Specifies a texel offset in the x direction within the texture array.<br>
-- param yoffset Specifies a texel offset in the y direction within the texture array.<br>
-- param width Specifies the width of the texture subimage.<br>
-- param height Specifies the height of the texture subimage.<br>
-- param dataLen Specifies the totoal size of compressed subimage in bytes.<br>
-- param level Specifies the level-of-detail number. Level 0 is the base image level. Level n is the nth mipmap reduction image.<br>
-- param data Specifies a pointer to the compressed image data in memory.
-- @function [parent=#Texture2DBackend] updateCompressedSubData 
-- @param self
-- @param #unsigned int xoffset
-- @param #unsigned int yoffset
-- @param #unsigned int width
-- @param #unsigned int height
-- @param #unsigned int dataLen
-- @param #unsigned int level
-- @param #unsigned char data
-- @return backend::Texture2DBackend#backend::Texture2DBackend self (return value: cc.backend::Texture2DBackend)
        
return nil
