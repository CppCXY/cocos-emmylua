
--------------------------------
-- @module TextureData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#TextureData] getContourData 
-- @param self
-- @param #int index
-- @return ContourData#ContourData ret (return value: ccs.ContourData)
        
--------------------------------
-- 
-- @function [parent=#TextureData] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#TextureData] addContourData 
-- @param self
-- @param #ccs.ContourData contourData
-- @return TextureData#TextureData self (return value: ccs.TextureData)
        
--------------------------------
-- 
-- @function [parent=#TextureData] create 
-- @param self
-- @return TextureData#TextureData ret (return value: ccs.TextureData)
        
--------------------------------
-- js ctor
-- @function [parent=#TextureData] TextureData 
-- @param self
-- @return TextureData#TextureData self (return value: ccs.TextureData)
        
return nil
