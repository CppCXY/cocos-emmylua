
--------------------------------
-- @module EventListenerPhysicsContactWithGroup
-- @extend EventListenerPhysicsContact
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithGroup] hitTest 
-- @param self
-- @param #cc.PhysicsShape shapeA
-- @param #cc.PhysicsShape shapeB
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Create the listener. 
-- @function [parent=#EventListenerPhysicsContactWithGroup] create 
-- @param self
-- @param #int group
-- @return EventListenerPhysicsContactWithGroup#EventListenerPhysicsContactWithGroup ret (return value: cc.EventListenerPhysicsContactWithGroup)
        
--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithGroup] clone 
-- @param self
-- @return EventListenerPhysicsContactWithGroup#EventListenerPhysicsContactWithGroup ret (return value: cc.EventListenerPhysicsContactWithGroup)
        
return nil
