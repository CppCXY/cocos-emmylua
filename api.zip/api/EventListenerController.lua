
--------------------------------
-- @module EventListenerController
-- @extend EventListener
-- @parent_module cc

--------------------------------
--  Create a controller event listener.<br>
-- return An autoreleased EventListenerController object.
-- @function [parent=#EventListenerController] create 
-- @param self
-- @return EventListenerController#EventListenerController ret (return value: cc.EventListenerController)
        
--------------------------------
-- 
-- @function [parent=#EventListenerController] clone 
-- @param self
-- @return EventListenerController#EventListenerController ret (return value: cc.EventListenerController)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerController] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
return nil
