
--------------------------------
-- @module RenderState
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#RenderState] getName 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- Binds the render state for this RenderState and any of its parents, top-down,<br>
-- for the given pass.
-- @function [parent=#RenderState] bindPass 
-- @param self
-- @param #cc.Pass pass
-- @param #cc.MeshCommand 
-- @return RenderState#RenderState self (return value: cc.RenderState)
        
return nil
