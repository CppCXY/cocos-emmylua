
--------------------------------
-- @module AudioProfile
-- @parent_module cc

--------------------------------
-- Default constructor<br>
-- lua new
-- @function [parent=#AudioProfile] AudioProfile 
-- @param self
-- @return AudioProfile#AudioProfile self (return value: cc.AudioProfile)
        
return nil
