
--------------------------------
-- @module EaseBounceIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseBounceIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBounceIn#EaseBounceIn ret (return value: cc.EaseBounceIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceIn] clone 
-- @param self
-- @return EaseBounceIn#EaseBounceIn ret (return value: cc.EaseBounceIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceIn] update 
-- @param self
-- @param #float time
-- @return EaseBounceIn#EaseBounceIn self (return value: cc.EaseBounceIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceIn] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceIn] EaseBounceIn 
-- @param self
-- @return EaseBounceIn#EaseBounceIn self (return value: cc.EaseBounceIn)
        
return nil
