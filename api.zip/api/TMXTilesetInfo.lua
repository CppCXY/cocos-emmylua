
--------------------------------
-- @module TMXTilesetInfo
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TMXTilesetInfo] getRectForGID 
-- @param self
-- @param #unsigned int gid
-- @return rect_table#rect_table ret (return value: rect_table)
        
--------------------------------
-- js ctor
-- @function [parent=#TMXTilesetInfo] TMXTilesetInfo 
-- @param self
-- @return TMXTilesetInfo#TMXTilesetInfo self (return value: cc.TMXTilesetInfo)
        
return nil
