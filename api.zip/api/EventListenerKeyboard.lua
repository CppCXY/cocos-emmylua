
--------------------------------
-- @module EventListenerKeyboard
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerKeyboard] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerKeyboard] clone 
-- @param self
-- @return EventListenerKeyboard#EventListenerKeyboard ret (return value: cc.EventListenerKeyboard)
        
--------------------------------
-- 
-- @function [parent=#EventListenerKeyboard] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#EventListenerKeyboard] EventListenerKeyboard 
-- @param self
-- @return EventListenerKeyboard#EventListenerKeyboard self (return value: cc.EventListenerKeyboard)
        
return nil
