
--------------------------------
-- @module ComExtensionData
-- @extend Component
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ComExtensionData] setActionTag 
-- @param self
-- @param #int actionTag
-- @return ComExtensionData#ComExtensionData self (return value: ccs.ComExtensionData)
        
--------------------------------
-- 
-- @function [parent=#ComExtensionData] getCustomProperty 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#ComExtensionData] getActionTag 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#ComExtensionData] setCustomProperty 
-- @param self
-- @param #string customProperty
-- @return ComExtensionData#ComExtensionData self (return value: ccs.ComExtensionData)
        
--------------------------------
-- 
-- @function [parent=#ComExtensionData] create 
-- @param self
-- @return ComExtensionData#ComExtensionData ret (return value: ccs.ComExtensionData)
        
--------------------------------
-- 
-- @function [parent=#ComExtensionData] createInstance 
-- @param self
-- @return Ref#Ref ret (return value: cc.Ref)
        
--------------------------------
-- 
-- @function [parent=#ComExtensionData] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#ComExtensionData] onRemove 
-- @param self
-- @return ComExtensionData#ComExtensionData self (return value: ccs.ComExtensionData)
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#ComExtensionData] onAdd 
-- @param self
-- @return ComExtensionData#ComExtensionData self (return value: ccs.ComExtensionData)
        
--------------------------------
-- 
-- @function [parent=#ComExtensionData] ComExtensionData 
-- @param self
-- @return ComExtensionData#ComExtensionData self (return value: ccs.ComExtensionData)
        
return nil
