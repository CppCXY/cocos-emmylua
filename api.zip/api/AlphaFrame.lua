
--------------------------------
-- @module AlphaFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#AlphaFrame] getAlpha 
-- @param self
-- @return unsigned char#unsigned char ret (return value: unsigned char)
        
--------------------------------
-- 
-- @function [parent=#AlphaFrame] setAlpha 
-- @param self
-- @param #unsigned char alpha
-- @return AlphaFrame#AlphaFrame self (return value: ccs.AlphaFrame)
        
--------------------------------
-- 
-- @function [parent=#AlphaFrame] create 
-- @param self
-- @return AlphaFrame#AlphaFrame ret (return value: ccs.AlphaFrame)
        
--------------------------------
-- 
-- @function [parent=#AlphaFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#AlphaFrame] AlphaFrame 
-- @param self
-- @return AlphaFrame#AlphaFrame self (return value: ccs.AlphaFrame)
        
return nil
