
--------------------------------
-- @module TransitionZoomFlipY
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionZoomFlipY] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionZoomFlipY#TransitionZoomFlipY ret (return value: cc.TransitionZoomFlipY)

--------------------------------
-- 
-- @function [parent=#TransitionZoomFlipY] TransitionZoomFlipY 
-- @param self
-- @return TransitionZoomFlipY#TransitionZoomFlipY self (return value: cc.TransitionZoomFlipY)
        
return nil
