
--------------------------------
-- @module TMXLayerInfo
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TMXLayerInfo] setProperties 
-- @param self
-- @param #map_table properties
-- @return TMXLayerInfo#TMXLayerInfo self (return value: cc.TMXLayerInfo)
        
--------------------------------
-- 
-- @function [parent=#TMXLayerInfo] getProperties 
-- @param self
-- @return map_table#map_table ret (return value: map_table)
        
--------------------------------
-- js ctor
-- @function [parent=#TMXLayerInfo] TMXLayerInfo 
-- @param self
-- @return TMXLayerInfo#TMXLayerInfo self (return value: cc.TMXLayerInfo)
        
return nil
