
--------------------------------
-- @module EaseQuinticActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuinticActionInOut#EaseQuinticActionInOut ret (return value: cc.EaseQuinticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] clone 
-- @param self
-- @return EaseQuinticActionInOut#EaseQuinticActionInOut ret (return value: cc.EaseQuinticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] update 
-- @param self
-- @param #float time
-- @return EaseQuinticActionInOut#EaseQuinticActionInOut self (return value: cc.EaseQuinticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] EaseQuinticActionInOut 
-- @param self
-- @return EaseQuinticActionInOut#EaseQuinticActionInOut self (return value: cc.EaseQuinticActionInOut)
        
return nil
