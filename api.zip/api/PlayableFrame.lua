
--------------------------------
-- @module PlayableFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#PlayableFrame] setPlayableAct 
-- @param self
-- @param #string playact
-- @return PlayableFrame#PlayableFrame self (return value: ccs.PlayableFrame)
        
--------------------------------
-- 
-- @function [parent=#PlayableFrame] getPlayableAct 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#PlayableFrame] create 
-- @param self
-- @return PlayableFrame#PlayableFrame ret (return value: ccs.PlayableFrame)
        
--------------------------------
-- 
-- @function [parent=#PlayableFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#PlayableFrame] PlayableFrame 
-- @param self
-- @return PlayableFrame#PlayableFrame self (return value: ccs.PlayableFrame)
        
return nil
