
--------------------------------
-- @module ToggleVisibility
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  Allocates and initializes the action.<br>
-- return An autoreleased ToggleVisibility object.
-- @function [parent=#ToggleVisibility] create 
-- @param self
-- @return ToggleVisibility#ToggleVisibility ret (return value: cc.ToggleVisibility)
        
--------------------------------
-- 
-- @function [parent=#ToggleVisibility] clone 
-- @param self
-- @return ToggleVisibility#ToggleVisibility ret (return value: cc.ToggleVisibility)
        
--------------------------------
-- param time In seconds.
-- @function [parent=#ToggleVisibility] update 
-- @param self
-- @param #float time
-- @return ToggleVisibility#ToggleVisibility self (return value: cc.ToggleVisibility)
        
--------------------------------
-- 
-- @function [parent=#ToggleVisibility] reverse 
-- @param self
-- @return ToggleVisibility#ToggleVisibility ret (return value: cc.ToggleVisibility)
        
--------------------------------
-- 
-- @function [parent=#ToggleVisibility] ToggleVisibility 
-- @param self
-- @return ToggleVisibility#ToggleVisibility self (return value: cc.ToggleVisibility)
        
return nil
