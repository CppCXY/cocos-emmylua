
--------------------------------
-- @module BoneData
-- @extend BaseData
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#BoneData] getDisplayData 
-- @param self
-- @param #int index
-- @return DisplayData#DisplayData ret (return value: ccs.DisplayData)
        
--------------------------------
-- 
-- @function [parent=#BoneData] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#BoneData] addDisplayData 
-- @param self
-- @param #ccs.DisplayData displayData
-- @return BoneData#BoneData self (return value: ccs.BoneData)
        
--------------------------------
-- 
-- @function [parent=#BoneData] create 
-- @param self
-- @return BoneData#BoneData ret (return value: ccs.BoneData)
        
--------------------------------
-- js ctor
-- @function [parent=#BoneData] BoneData 
-- @param self
-- @return BoneData#BoneData self (return value: ccs.BoneData)
        
return nil
