
--------------------------------
-- @module EventListenerAssetsManagerEx
-- @extend EventListenerCustom
-- @parent_module cc

--------------------------------
--  Initializes event with type and callback function 
-- @function [parent=#EventListenerAssetsManagerEx] init 
-- @param self
-- @param #cc.AssetsManagerEx AssetsManagerEx
-- @param #function callback
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#EventListenerAssetsManagerEx] clone 
-- @param self
-- @return EventListenerAssetsManagerEx#EventListenerAssetsManagerEx ret (return value: cc.EventListenerAssetsManagerEx)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerAssetsManagerEx] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Constructor 
-- @function [parent=#EventListenerAssetsManagerEx] EventListenerAssetsManagerEx 
-- @param self
-- @return EventListenerAssetsManagerEx#EventListenerAssetsManagerEx self (return value: cc.EventListenerAssetsManagerEx)
        
return nil
