
--------------------------------
-- @module ShaderCache
-- @extend Ref
-- @parent_module cc

--------------------------------
-- Remove all unused shaders.
-- @function [parent=#ShaderCache] removeUnusedShader 
-- @param self
-- @return backend::ShaderCache#backend::ShaderCache self (return value: cc.backend::ShaderCache)
        
--------------------------------
--  purges the cache. It releases the retained instance. 
-- @function [parent=#ShaderCache] destroyInstance 
-- @param self
-- @return backend::ShaderCache#backend::ShaderCache self (return value: cc.backend::ShaderCache)
        
--------------------------------
-- Create a vertex shader module and add it to cache.<br>
-- If it is created before, then just return the cached shader module.<br>
-- param shaderSource The source code of the shader.
-- @function [parent=#ShaderCache] newVertexShaderModule 
-- @param self
-- @param #string shaderSource
-- @return backend::ShaderModule#backend::ShaderModule ret (return value: cc.backend::ShaderModule)
        
--------------------------------
-- Create a fragment shader module.<br>
-- If it is created before, then just return the cached shader module.<br>
-- param shaderSource The source code of the shader.
-- @function [parent=#ShaderCache] newFragmentShaderModule 
-- @param self
-- @param #string shaderSource
-- @return backend::ShaderModule#backend::ShaderModule ret (return value: cc.backend::ShaderModule)
        
--------------------------------
--  returns the shared instance 
-- @function [parent=#ShaderCache] getInstance 
-- @param self
-- @return backend::ShaderCache#backend::ShaderCache ret (return value: cc.backend::ShaderCache)
        
return nil
