
--------------------------------
-- @module ZOrderFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ZOrderFrame] getZOrder 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#ZOrderFrame] setZOrder 
-- @param self
-- @param #int zorder
-- @return ZOrderFrame#ZOrderFrame self (return value: ccs.ZOrderFrame)
        
--------------------------------
-- 
-- @function [parent=#ZOrderFrame] create 
-- @param self
-- @return ZOrderFrame#ZOrderFrame ret (return value: ccs.ZOrderFrame)
        
--------------------------------
-- 
-- @function [parent=#ZOrderFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#ZOrderFrame] ZOrderFrame 
-- @param self
-- @return ZOrderFrame#ZOrderFrame self (return value: ccs.ZOrderFrame)
        
return nil
