
--------------------------------
-- @module Program
-- @extend Ref
-- @parent_module ccb

--------------------------------
-- Get maximum vertex location.<br>
-- return Maximum vertex locaiton.
-- @function [parent=#Program] getMaxVertexLocation 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get maximum fragment location.<br>
-- return Maximum fragment location.
-- @function [parent=#Program] getMaxFragmentLocation 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get fragment shader.<br>
-- Fragment shader.
-- @function [parent=#Program] getFragmentShader 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- Get uniform buffer size in bytes that can hold all the uniforms.<br>
-- param stage Specifies the shader stage. The symbolic constant can be either VERTEX or FRAGMENT.<br>
-- return The uniform buffer size in bytes.
-- @function [parent=#Program] getUniformBufferSize 
-- @param self
-- @param #int stage
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- @overload self, int         
-- @overload self, string         
-- @function [parent=#Program] getUniformLocation
-- @param self
-- @param #string uniform
-- @return backend::UniformLocation#backend::UniformLocation ret (return value: cc.backend::UniformLocation)

--------------------------------
-- Get engine built-in program type.<br>
-- return The built-in program type.
-- @function [parent=#Program] getProgramType 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get active vertex attributes.<br>
-- return Active vertex attributes. key is active attribute name, Value is corresponding attribute info.
-- @function [parent=#Program] getActiveAttributes 
-- @param self
-- @return map_table#map_table ret (return value: map_table)
        
--------------------------------
-- @overload self, int         
-- @overload self, string         
-- @function [parent=#Program] getAttributeLocation
-- @param self
-- @param #string name
-- @return int#int ret (return value: int)

--------------------------------
-- Get vertex shader.<br>
-- return Vertex shader.
-- @function [parent=#Program] getVertexShader 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- Get engine built-in program.<br>
-- param type Specifies the built-in program type.
-- @function [parent=#Program] getBuiltinProgram 
-- @param self
-- @param #int type
-- @return backend::Program#backend::Program ret (return value: cc.backend::Program)
        
return nil
