
--------------------------------
-- @module BaseData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#BaseData] getColor 
-- @param self
-- @return color4b_table#color4b_table ret (return value: color4b_table)
        
--------------------------------
-- 
-- @function [parent=#BaseData] setColor 
-- @param self
-- @param #color4b_table color
-- @return BaseData#BaseData self (return value: ccs.BaseData)
        
--------------------------------
-- 
-- @function [parent=#BaseData] create 
-- @param self
-- @return BaseData#BaseData ret (return value: ccs.BaseData)
        
--------------------------------
-- js ctor
-- @function [parent=#BaseData] BaseData 
-- @param self
-- @return BaseData#BaseData self (return value: ccs.BaseData)
        
return nil
