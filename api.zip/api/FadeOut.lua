
--------------------------------
-- @module FadeOut
-- @extend FadeTo
-- @parent_module cc

--------------------------------
-- js NA
-- @function [parent=#FadeOut] setReverseAction 
-- @param self
-- @param #cc.FadeTo ac
-- @return FadeOut#FadeOut self (return value: cc.FadeOut)
        
--------------------------------
-- Creates the action.<br>
-- param d Duration time, in seconds.
-- @function [parent=#FadeOut] create 
-- @param self
-- @param #float d
-- @return FadeOut#FadeOut ret (return value: cc.FadeOut)
        
--------------------------------
-- 
-- @function [parent=#FadeOut] startWithTarget 
-- @param self
-- @param #cc.Node target
-- @return FadeOut#FadeOut self (return value: cc.FadeOut)
        
--------------------------------
-- 
-- @function [parent=#FadeOut] clone 
-- @param self
-- @return FadeOut#FadeOut ret (return value: cc.FadeOut)
        
--------------------------------
-- 
-- @function [parent=#FadeOut] reverse 
-- @param self
-- @return FadeTo#FadeTo ret (return value: cc.FadeTo)
        
--------------------------------
-- 
-- @function [parent=#FadeOut] FadeOut 
-- @param self
-- @return FadeOut#FadeOut self (return value: cc.FadeOut)
        
return nil
