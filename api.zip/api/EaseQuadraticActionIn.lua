
--------------------------------
-- @module EaseQuadraticActionIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuadraticActionIn#EaseQuadraticActionIn ret (return value: cc.EaseQuadraticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] clone 
-- @param self
-- @return EaseQuadraticActionIn#EaseQuadraticActionIn ret (return value: cc.EaseQuadraticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] update 
-- @param self
-- @param #float time
-- @return EaseQuadraticActionIn#EaseQuadraticActionIn self (return value: cc.EaseQuadraticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] EaseQuadraticActionIn 
-- @param self
-- @return EaseQuadraticActionIn#EaseQuadraticActionIn self (return value: cc.EaseQuadraticActionIn)
        
return nil
