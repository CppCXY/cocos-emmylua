
--------------------------------
-- @module EventTouch
-- @extend Event
-- @parent_module cc

--------------------------------
--  Get event code.<br>
-- return The code of the event.
-- @function [parent=#EventTouch] getEventCode 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Set the event code.<br>
-- param eventCode A given EventCode.
-- @function [parent=#EventTouch] setEventCode 
-- @param self
-- @param #int eventCode
-- @return EventTouch#EventTouch self (return value: cc.EventTouch)
        
--------------------------------
-- Constructor.<br>
-- js NA
-- @function [parent=#EventTouch] EventTouch 
-- @param self
-- @return EventTouch#EventTouch self (return value: cc.EventTouch)
        
return nil
