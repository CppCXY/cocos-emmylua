
--------------------------------
-- @module ComponentLua
-- @extend Component
-- @parent_module cc

--------------------------------
-- This function is used to be invoked from lua side to get the corresponding script object of this component.
-- @function [parent=#ComponentLua] getScriptObject 
-- @param self
-- @return void#void ret (return value: void)
        
--------------------------------
-- 
-- @function [parent=#ComponentLua] update 
-- @param self
-- @param #float dt
-- @return ComponentLua#ComponentLua self (return value: cc.ComponentLua)
        
--------------------------------
-- 
-- @function [parent=#ComponentLua] create 
-- @param self
-- @param #string scriptFileName
-- @return ComponentLua#ComponentLua ret (return value: cc.ComponentLua)
        
--------------------------------
-- 
-- @function [parent=#ComponentLua] ComponentLua 
-- @param self
-- @param #string scriptFileName
-- @return ComponentLua#ComponentLua self (return value: cc.ComponentLua)
        
return nil
