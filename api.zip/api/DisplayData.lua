
--------------------------------
-- @module DisplayData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#DisplayData] copy 
-- @param self
-- @param #ccs.DisplayData displayData
-- @return DisplayData#DisplayData self (return value: ccs.DisplayData)
        
--------------------------------
-- 
-- @function [parent=#DisplayData] changeDisplayToTexture 
-- @param self
-- @param #string displayName
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#DisplayData] create 
-- @param self
-- @return DisplayData#DisplayData ret (return value: ccs.DisplayData)
        
--------------------------------
-- js ctor
-- @function [parent=#DisplayData] DisplayData 
-- @param self
-- @return DisplayData#DisplayData self (return value: ccs.DisplayData)
        
return nil
