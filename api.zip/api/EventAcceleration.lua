
--------------------------------
-- @module EventAcceleration
-- @extend Event
-- @parent_module cc

return nil
