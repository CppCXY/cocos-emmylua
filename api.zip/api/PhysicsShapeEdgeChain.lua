
--------------------------------
-- @module PhysicsShapeEdgeChain
-- @extend PhysicsShape
-- @parent_module cc

--------------------------------
-- Get this chain's points array count.<br>
-- return An integer number.
-- @function [parent=#PhysicsShapeEdgeChain] getPointsCount 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get this chain's center position.<br>
-- return A Vec2 object.
-- @function [parent=#PhysicsShapeEdgeChain] getCenter 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
return nil
