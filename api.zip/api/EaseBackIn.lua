
--------------------------------
-- @module EaseBackIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseBackIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBackIn#EaseBackIn ret (return value: cc.EaseBackIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBackIn] clone 
-- @param self
-- @return EaseBackIn#EaseBackIn ret (return value: cc.EaseBackIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBackIn] update 
-- @param self
-- @param #float time
-- @return EaseBackIn#EaseBackIn self (return value: cc.EaseBackIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBackIn] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseBackIn] EaseBackIn 
-- @param self
-- @return EaseBackIn#EaseBackIn self (return value: cc.EaseBackIn)
        
return nil
