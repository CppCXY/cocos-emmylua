
--------------------------------
-- @module EaseIn
-- @extend EaseRateAction
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @param #float rate
-- @return EaseIn#EaseIn ret (return value: cc.EaseIn)
        
--------------------------------
-- 
-- @function [parent=#EaseIn] clone 
-- @param self
-- @return EaseIn#EaseIn ret (return value: cc.EaseIn)
        
--------------------------------
-- 
-- @function [parent=#EaseIn] update 
-- @param self
-- @param #float time
-- @return EaseIn#EaseIn self (return value: cc.EaseIn)
        
--------------------------------
-- 
-- @function [parent=#EaseIn] reverse 
-- @param self
-- @return EaseRateAction#EaseRateAction ret (return value: cc.EaseRateAction)
        
--------------------------------
-- 
-- @function [parent=#EaseIn] EaseIn 
-- @param self
-- @return EaseIn#EaseIn self (return value: cc.EaseIn)
        
return nil
