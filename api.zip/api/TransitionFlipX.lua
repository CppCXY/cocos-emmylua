
--------------------------------
-- @module TransitionFlipX
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionFlipX] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionFlipX#TransitionFlipX ret (return value: cc.TransitionFlipX)

--------------------------------
-- 
-- @function [parent=#TransitionFlipX] TransitionFlipX 
-- @param self
-- @return TransitionFlipX#TransitionFlipX self (return value: cc.TransitionFlipX)
        
return nil
