
--------------------------------
-- @module FastTMXTiledMap
-- @extend Node
-- @parent_module cc

--------------------------------
--  Set object groups. <br>
-- param groups An object groups.
-- @function [parent=#FastTMXTiledMap] setObjectGroups 
-- @param self
-- @param #array_table groups
-- @return FastTMXTiledMap#FastTMXTiledMap self (return value: cc.FastTMXTiledMap)
        
--------------------------------
--  Return the value for the specific property name.<br>
-- return Return the value for the specific property name.
-- @function [parent=#FastTMXTiledMap] getProperty 
-- @param self
-- @param #string propertyName
-- @return Value#Value ret (return value: cc.Value)
        
--------------------------------
--  Set the map's size property measured in tiles.<br>
-- param mapSize The map's size property measured in tiles.
-- @function [parent=#FastTMXTiledMap] setMapSize 
-- @param self
-- @param #size_table mapSize
-- @return FastTMXTiledMap#FastTMXTiledMap self (return value: cc.FastTMXTiledMap)
        
--------------------------------
--  Return the TMXObjectGroup for the specific group. <br>
-- return Return the TMXObjectGroup for the specific group.
-- @function [parent=#FastTMXTiledMap] getObjectGroup 
-- @param self
-- @param #string groupName
-- @return TMXObjectGroup#TMXObjectGroup ret (return value: cc.TMXObjectGroup)
        
--------------------------------
-- @overload self         
-- @overload self         
-- @function [parent=#FastTMXTiledMap] getObjectGroups
-- @param self
-- @return array_table#array_table ret (return value: array_table)

--------------------------------
--  The tiles's size property measured in pixels.<br>
-- return The tiles's size property measured in pixels.
-- @function [parent=#FastTMXTiledMap] getTileSize 
-- @param self
-- @return size_table#size_table ret (return value: size_table)
        
--------------------------------
--  The map's size property measured in tiles. <br>
-- return The map's size property measured in tiles.
-- @function [parent=#FastTMXTiledMap] getMapSize 
-- @param self
-- @return size_table#size_table ret (return value: size_table)
        
--------------------------------
--  Get properties.<br>
-- return Properties.
-- @function [parent=#FastTMXTiledMap] getProperties 
-- @param self
-- @return map_table#map_table ret (return value: map_table)
        
--------------------------------
--  Return properties dictionary for tile GID.<br>
-- return Return properties dictionary for tile GID.
-- @function [parent=#FastTMXTiledMap] getPropertiesForGID 
-- @param self
-- @param #int GID
-- @return Value#Value ret (return value: cc.Value)
        
--------------------------------
--  Set the tiles's size property measured in pixels. <br>
-- param tileSize The tiles's size property measured in pixels.
-- @function [parent=#FastTMXTiledMap] setTileSize 
-- @param self
-- @param #size_table tileSize
-- @return FastTMXTiledMap#FastTMXTiledMap self (return value: cc.FastTMXTiledMap)
        
--------------------------------
--  Set properties. <br>
-- param properties An ValueMap Properties.
-- @function [parent=#FastTMXTiledMap] setProperties 
-- @param self
-- @param #map_table properties
-- @return FastTMXTiledMap#FastTMXTiledMap self (return value: cc.FastTMXTiledMap)
        
--------------------------------
--  Return the FastTMXLayer for the specific layer. <br>
-- return Return the FastTMXLayer for the specific layer.
-- @function [parent=#FastTMXTiledMap] getLayer 
-- @param self
-- @param #string layerName
-- @return FastTMXLayer#FastTMXLayer ret (return value: cc.FastTMXLayer)
        
--------------------------------
--  Get map orientation. <br>
-- return The map orientation.
-- @function [parent=#FastTMXTiledMap] getMapOrientation 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Set map orientation. <br>
-- param mapOrientation The map orientation.
-- @function [parent=#FastTMXTiledMap] setMapOrientation 
-- @param self
-- @param #int mapOrientation
-- @return FastTMXTiledMap#FastTMXTiledMap self (return value: cc.FastTMXTiledMap)
        
--------------------------------
--  Creates a TMX Tiled Map with a TMX file.<br>
-- return An autorelease object.
-- @function [parent=#FastTMXTiledMap] create 
-- @param self
-- @param #string tmxFile
-- @return FastTMXTiledMap#FastTMXTiledMap ret (return value: cc.FastTMXTiledMap)
        
--------------------------------
--  Initializes a TMX Tiled Map with a TMX formatted XML string and a path to TMX resources. <br>
-- param tmxString A TMX formatted XML string.<br>
-- param resourcePath A path to TMX resources.<br>
-- return An autorelease object.
-- @function [parent=#FastTMXTiledMap] createWithXML 
-- @param self
-- @param #string tmxString
-- @param #string resourcePath
-- @return FastTMXTiledMap#FastTMXTiledMap ret (return value: cc.FastTMXTiledMap)
        
--------------------------------
-- 
-- @function [parent=#FastTMXTiledMap] getDescription 
-- @param self
-- @return string#string ret (return value: string)
        
return nil
