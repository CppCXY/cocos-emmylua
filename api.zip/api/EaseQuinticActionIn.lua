
--------------------------------
-- @module EaseQuinticActionIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuinticActionIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuinticActionIn#EaseQuinticActionIn ret (return value: cc.EaseQuinticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionIn] clone 
-- @param self
-- @return EaseQuinticActionIn#EaseQuinticActionIn ret (return value: cc.EaseQuinticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionIn] update 
-- @param self
-- @param #float time
-- @return EaseQuinticActionIn#EaseQuinticActionIn self (return value: cc.EaseQuinticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionIn] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionIn] EaseQuinticActionIn 
-- @param self
-- @return EaseQuinticActionIn#EaseQuinticActionIn self (return value: cc.EaseQuinticActionIn)
        
return nil
