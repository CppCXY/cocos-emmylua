
--------------------------------
-- @module MovementData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#MovementData] getMovementBoneData 
-- @param self
-- @param #string boneName
-- @return MovementBoneData#MovementBoneData ret (return value: ccs.MovementBoneData)
        
--------------------------------
-- 
-- @function [parent=#MovementData] addMovementBoneData 
-- @param self
-- @param #ccs.MovementBoneData movBoneData
-- @return MovementData#MovementData self (return value: ccs.MovementData)
        
--------------------------------
-- 
-- @function [parent=#MovementData] create 
-- @param self
-- @return MovementData#MovementData ret (return value: ccs.MovementData)
        
--------------------------------
-- js ctor
-- @function [parent=#MovementData] MovementData 
-- @param self
-- @return MovementData#MovementData self (return value: ccs.MovementData)
        
return nil
