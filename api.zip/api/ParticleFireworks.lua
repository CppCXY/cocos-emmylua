
--------------------------------
-- @module ParticleFireworks
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleFireworks] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ParticleFireworks] initWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Create a fireworks particle system.<br>
-- return An autoreleased ParticleFireworks object.
-- @function [parent=#ParticleFireworks] create 
-- @param self
-- @return ParticleFireworks#ParticleFireworks ret (return value: cc.ParticleFireworks)
        
--------------------------------
--  Create a fireworks particle system withe a fixed number of particles.<br>
-- param numberOfParticles A given number of particles.<br>
-- return An autoreleased ParticleFireworks object.<br>
-- js NA
-- @function [parent=#ParticleFireworks] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleFireworks#ParticleFireworks ret (return value: cc.ParticleFireworks)
        
--------------------------------
-- js ctor
-- @function [parent=#ParticleFireworks] ParticleFireworks 
-- @param self
-- @return ParticleFireworks#ParticleFireworks self (return value: cc.ParticleFireworks)
        
return nil
