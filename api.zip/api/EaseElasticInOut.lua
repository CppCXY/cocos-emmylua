
--------------------------------
-- @module EaseElasticInOut
-- @extend EaseElastic
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseElasticInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @param #float rate
-- @return EaseElasticInOut#EaseElasticInOut ret (return value: cc.EaseElasticInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseElasticInOut] clone 
-- @param self
-- @return EaseElasticInOut#EaseElasticInOut ret (return value: cc.EaseElasticInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseElasticInOut] update 
-- @param self
-- @param #float time
-- @return EaseElasticInOut#EaseElasticInOut self (return value: cc.EaseElasticInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseElasticInOut] reverse 
-- @param self
-- @return EaseElastic#EaseElastic ret (return value: cc.EaseElastic)
        
--------------------------------
-- 
-- @function [parent=#EaseElasticInOut] EaseElasticInOut 
-- @param self
-- @return EaseElasticInOut#EaseElasticInOut self (return value: cc.EaseElasticInOut)
        
return nil
