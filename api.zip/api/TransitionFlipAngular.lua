
--------------------------------
-- @module TransitionFlipAngular
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionFlipAngular] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionFlipAngular#TransitionFlipAngular ret (return value: cc.TransitionFlipAngular)

--------------------------------
-- 
-- @function [parent=#TransitionFlipAngular] TransitionFlipAngular 
-- @param self
-- @return TransitionFlipAngular#TransitionFlipAngular self (return value: cc.TransitionFlipAngular)
        
return nil
