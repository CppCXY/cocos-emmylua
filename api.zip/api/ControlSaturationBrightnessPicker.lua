
--------------------------------
-- @module ControlSaturationBrightnessPicker
-- @extend Control
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] getShadow 
-- @param self
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] initWithTargetAndPos 
-- @param self
-- @param #cc.Node target
-- @param #vec2_table pos
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] getStartPos 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] getOverlay 
-- @param self
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] getSlider 
-- @param self
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] getBackground 
-- @param self
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] getSaturation 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] getBrightness 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] create 
-- @param self
-- @param #cc.Node target
-- @param #vec2_table pos
-- @return ControlSaturationBrightnessPicker#ControlSaturationBrightnessPicker ret (return value: cc.ControlSaturationBrightnessPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlSaturationBrightnessPicker] setEnabled 
-- @param self
-- @param #bool enabled
-- @return ControlSaturationBrightnessPicker#ControlSaturationBrightnessPicker self (return value: cc.ControlSaturationBrightnessPicker)
        
--------------------------------
-- js ctor
-- @function [parent=#ControlSaturationBrightnessPicker] ControlSaturationBrightnessPicker 
-- @param self
-- @return ControlSaturationBrightnessPicker#ControlSaturationBrightnessPicker self (return value: cc.ControlSaturationBrightnessPicker)
        
return nil
