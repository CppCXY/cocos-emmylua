
--------------------------------
-- @module AnchorPointFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#AnchorPointFrame] setAnchorPoint 
-- @param self
-- @param #vec2_table point
-- @return AnchorPointFrame#AnchorPointFrame self (return value: ccs.AnchorPointFrame)
        
--------------------------------
-- 
-- @function [parent=#AnchorPointFrame] getAnchorPoint 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#AnchorPointFrame] create 
-- @param self
-- @return AnchorPointFrame#AnchorPointFrame ret (return value: ccs.AnchorPointFrame)
        
--------------------------------
-- 
-- @function [parent=#AnchorPointFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#AnchorPointFrame] AnchorPointFrame 
-- @param self
-- @return AnchorPointFrame#AnchorPointFrame self (return value: ccs.AnchorPointFrame)
        
return nil
