
--------------------------------
-- @module EventListenerMouse
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerMouse] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerMouse] clone 
-- @param self
-- @return EventListenerMouse#EventListenerMouse ret (return value: cc.EventListenerMouse)
        
--------------------------------
-- 
-- @function [parent=#EventListenerMouse] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#EventListenerMouse] EventListenerMouse 
-- @param self
-- @return EventListenerMouse#EventListenerMouse self (return value: cc.EventListenerMouse)
        
return nil
