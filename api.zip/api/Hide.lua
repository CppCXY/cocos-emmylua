
--------------------------------
-- @module Hide
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  Allocates and initializes the action.<br>
-- return An autoreleased Hide object.
-- @function [parent=#Hide] create 
-- @param self
-- @return Hide#Hide ret (return value: cc.Hide)
        
--------------------------------
-- 
-- @function [parent=#Hide] clone 
-- @param self
-- @return Hide#Hide ret (return value: cc.Hide)
        
--------------------------------
-- param time In seconds.
-- @function [parent=#Hide] update 
-- @param self
-- @param #float time
-- @return Hide#Hide self (return value: cc.Hide)
        
--------------------------------
-- 
-- @function [parent=#Hide] reverse 
-- @param self
-- @return ActionInstant#ActionInstant ret (return value: cc.ActionInstant)
        
--------------------------------
-- 
-- @function [parent=#Hide] Hide 
-- @param self
-- @return Hide#Hide self (return value: cc.Hide)
        
return nil
