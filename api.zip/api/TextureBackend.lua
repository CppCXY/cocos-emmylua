
--------------------------------
-- @module TextureBackend
-- @extend Ref
-- @parent_module ccb

--------------------------------
-- Get texture format.<br>
-- return Texture format.
-- @function [parent=#TextureBackend] getTextureFormat 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get texture type. Symbolic constant value can be either TEXTURE_2D or TEXTURE_CUBE.<br>
-- return Texture type.
-- @function [parent=#TextureBackend] getTextureType 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Update sampler<br>
-- param sampler Specifies the sampler descriptor.
-- @function [parent=#TextureBackend] updateSamplerDescriptor 
-- @param self
-- @param #cc.backend::SamplerDescriptor sampler
-- @return backend::TextureBackend#backend::TextureBackend self (return value: cc.backend::TextureBackend)
        
--------------------------------
-- Update texture description.<br>
-- param descriptor Specifies texture and sampler descriptor.
-- @function [parent=#TextureBackend] updateTextureDescriptor 
-- @param self
-- @param #cc.backend::TextureDescriptor descriptor
-- @return backend::TextureBackend#backend::TextureBackend self (return value: cc.backend::TextureBackend)
        
--------------------------------
-- Get texture usage. Symbolic constant can be READ, WRITE or RENDER_TARGET.<br>
-- return Texture usage.
-- @function [parent=#TextureBackend] getTextureUsage 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Check if mipmap had generated before.<br>
-- return true if the mipmap has always generated before, otherwise false.
-- @function [parent=#TextureBackend] hasMipmaps 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- / Generate mipmaps.
-- @function [parent=#TextureBackend] generateMipmaps 
-- @param self
-- @return backend::TextureBackend#backend::TextureBackend self (return value: cc.backend::TextureBackend)
        
--------------------------------
-- Read a block of pixels from the drawable texture<br>
-- param x,y Specify the window coordinates of the first pixel that is read from the drawable texture. This location is the lower left corner of a rectangular block of pixels.<br>
-- param width,height Specify the dimensions of the pixel rectangle. width and height of one correspond to a single pixel.<br>
-- param flipImage Specifies if needs to flip the image.<br>
-- param callback Specifies a call back function to deal with the image.
-- @function [parent=#TextureBackend] getBytes 
-- @param self
-- @param #unsigned int x
-- @param #unsigned int y
-- @param #unsigned int width
-- @param #unsigned int height
-- @param #bool flipImage
-- @param #function callback
-- @return backend::TextureBackend#backend::TextureBackend self (return value: cc.backend::TextureBackend)
        
return nil
