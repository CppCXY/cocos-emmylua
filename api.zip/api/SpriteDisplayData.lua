
--------------------------------
-- @module SpriteDisplayData
-- @extend DisplayData
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#SpriteDisplayData] copy 
-- @param self
-- @param #ccs.DisplayData displayData
-- @return SpriteDisplayData#SpriteDisplayData self (return value: ccs.SpriteDisplayData)
        
--------------------------------
-- 
-- @function [parent=#SpriteDisplayData] create 
-- @param self
-- @return SpriteDisplayData#SpriteDisplayData ret (return value: ccs.SpriteDisplayData)
        
--------------------------------
-- js ctor
-- @function [parent=#SpriteDisplayData] SpriteDisplayData 
-- @param self
-- @return SpriteDisplayData#SpriteDisplayData self (return value: ccs.SpriteDisplayData)
        
return nil
