
--------------------------------
-- @module EventListenerPhysicsContact
-- @extend EventListenerCustom
-- @parent_module cc

--------------------------------
--  Create the listener. 
-- @function [parent=#EventListenerPhysicsContact] create 
-- @param self
-- @return EventListenerPhysicsContact#EventListenerPhysicsContact ret (return value: cc.EventListenerPhysicsContact)
        
--------------------------------
--  Clone an object from this listener.
-- @function [parent=#EventListenerPhysicsContact] clone 
-- @param self
-- @return EventListenerPhysicsContact#EventListenerPhysicsContact ret (return value: cc.EventListenerPhysicsContact)
        
--------------------------------
--  Check the listener is available.<br>
-- return True if there's one available callback function at least, false if there's no one.
-- @function [parent=#EventListenerPhysicsContact] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
return nil
