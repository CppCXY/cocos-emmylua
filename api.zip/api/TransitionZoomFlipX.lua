
--------------------------------
-- @module TransitionZoomFlipX
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionZoomFlipX] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionZoomFlipX#TransitionZoomFlipX ret (return value: cc.TransitionZoomFlipX)

--------------------------------
-- 
-- @function [parent=#TransitionZoomFlipX] TransitionZoomFlipX 
-- @param self
-- @return TransitionZoomFlipX#TransitionZoomFlipX self (return value: cc.TransitionZoomFlipX)
        
return nil
