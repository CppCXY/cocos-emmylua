
--------------------------------
-- @module TransitionShrinkGrow
-- @extend TransitionScene,TransitionEaseScene
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionShrinkGrow] easeActionWithAction 
-- @param self
-- @param #cc.ActionInterval action
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
--  Creates a transition with duration and incoming scene.<br>
-- param t Duration time, in seconds.<br>
-- param scene A given scene.<br>
-- return A autoreleased TransitionShrinkGrow object.
-- @function [parent=#TransitionShrinkGrow] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionShrinkGrow#TransitionShrinkGrow ret (return value: cc.TransitionShrinkGrow)
        
--------------------------------
-- 
-- @function [parent=#TransitionShrinkGrow] TransitionShrinkGrow 
-- @param self
-- @return TransitionShrinkGrow#TransitionShrinkGrow self (return value: cc.TransitionShrinkGrow)
        
return nil
