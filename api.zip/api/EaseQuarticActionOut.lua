
--------------------------------
-- @module EaseQuarticActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuarticActionOut#EaseQuarticActionOut ret (return value: cc.EaseQuarticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] clone 
-- @param self
-- @return EaseQuarticActionOut#EaseQuarticActionOut ret (return value: cc.EaseQuarticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] update 
-- @param self
-- @param #float time
-- @return EaseQuarticActionOut#EaseQuarticActionOut self (return value: cc.EaseQuarticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] EaseQuarticActionOut 
-- @param self
-- @return EaseQuarticActionOut#EaseQuarticActionOut self (return value: cc.EaseQuarticActionOut)
        
return nil
