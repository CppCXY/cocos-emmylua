
--------------------------------
-- @module FadeIn
-- @extend FadeTo
-- @parent_module cc

--------------------------------
-- js NA
-- @function [parent=#FadeIn] setReverseAction 
-- @param self
-- @param #cc.FadeTo ac
-- @return FadeIn#FadeIn self (return value: cc.FadeIn)
        
--------------------------------
-- Creates the action.<br>
-- param d Duration time, in seconds.<br>
-- return An autoreleased FadeIn object.
-- @function [parent=#FadeIn] create 
-- @param self
-- @param #float d
-- @return FadeIn#FadeIn ret (return value: cc.FadeIn)
        
--------------------------------
-- 
-- @function [parent=#FadeIn] startWithTarget 
-- @param self
-- @param #cc.Node target
-- @return FadeIn#FadeIn self (return value: cc.FadeIn)
        
--------------------------------
-- 
-- @function [parent=#FadeIn] clone 
-- @param self
-- @return FadeIn#FadeIn ret (return value: cc.FadeIn)
        
--------------------------------
-- 
-- @function [parent=#FadeIn] reverse 
-- @param self
-- @return FadeTo#FadeTo ret (return value: cc.FadeTo)
        
--------------------------------
-- 
-- @function [parent=#FadeIn] FadeIn 
-- @param self
-- @return FadeIn#FadeIn self (return value: cc.FadeIn)
        
return nil
