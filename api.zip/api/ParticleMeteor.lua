
--------------------------------
-- @module ParticleMeteor
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleMeteor] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ParticleMeteor] initWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Create a meteor particle system.<br>
-- return An autoreleased ParticleMeteor object.
-- @function [parent=#ParticleMeteor] create 
-- @param self
-- @return ParticleMeteor#ParticleMeteor ret (return value: cc.ParticleMeteor)
        
--------------------------------
--  Create a meteor particle system withe a fixed number of particles.<br>
-- param numberOfParticles A given number of particles.<br>
-- return An autoreleased ParticleMeteor object.<br>
-- js NA
-- @function [parent=#ParticleMeteor] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleMeteor#ParticleMeteor ret (return value: cc.ParticleMeteor)
        
--------------------------------
-- js ctor
-- @function [parent=#ParticleMeteor] ParticleMeteor 
-- @param self
-- @return ParticleMeteor#ParticleMeteor self (return value: cc.ParticleMeteor)
        
return nil
