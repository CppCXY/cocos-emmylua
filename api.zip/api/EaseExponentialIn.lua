
--------------------------------
-- @module EaseExponentialIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseExponentialIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseExponentialIn#EaseExponentialIn ret (return value: cc.EaseExponentialIn)
        
--------------------------------
-- 
-- @function [parent=#EaseExponentialIn] clone 
-- @param self
-- @return EaseExponentialIn#EaseExponentialIn ret (return value: cc.EaseExponentialIn)
        
--------------------------------
-- 
-- @function [parent=#EaseExponentialIn] update 
-- @param self
-- @param #float time
-- @return EaseExponentialIn#EaseExponentialIn self (return value: cc.EaseExponentialIn)
        
--------------------------------
-- 
-- @function [parent=#EaseExponentialIn] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseExponentialIn] EaseExponentialIn 
-- @param self
-- @return EaseExponentialIn#EaseExponentialIn self (return value: cc.EaseExponentialIn)
        
return nil
