
--------------------------------
-- @module TextureCubemapBackend
-- @extend TextureBackend
-- @parent_module ccb

--------------------------------
-- Update texutre cube data in give slice side.<br>
-- param side Specifies which slice texture of cube to be update.<br>
-- param data Specifies a pointer to the image data in memory.
-- @function [parent=#TextureCubemapBackend] updateFaceData 
-- @param self
-- @param #int side
-- @param #void data
-- @return backend::TextureCubemapBackend#backend::TextureCubemapBackend self (return value: cc.backend::TextureCubemapBackend)
        
return nil
