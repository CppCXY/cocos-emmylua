
--------------------------------
-- @module CardinalSplineBy
-- @extend CardinalSplineTo
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] startWithTarget 
-- @param self
-- @param #cc.Node target
-- @return CardinalSplineBy#CardinalSplineBy self (return value: cc.CardinalSplineBy)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] clone 
-- @param self
-- @return CardinalSplineBy#CardinalSplineBy ret (return value: cc.CardinalSplineBy)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] updatePosition 
-- @param self
-- @param #vec2_table newPos
-- @return CardinalSplineBy#CardinalSplineBy self (return value: cc.CardinalSplineBy)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] reverse 
-- @param self
-- @return CardinalSplineBy#CardinalSplineBy ret (return value: cc.CardinalSplineBy)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] CardinalSplineBy 
-- @param self
-- @return CardinalSplineBy#CardinalSplineBy self (return value: cc.CardinalSplineBy)
        
return nil
