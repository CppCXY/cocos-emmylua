
--------------------------------
-- @module VertexLayout
-- @parent_module ccb

--------------------------------
-- Get vertex step function. Default value is VERTEX.<br>
-- return Vertex step function.<br>
-- note Used in metal.
-- @function [parent=#VertexLayout] getVertexStepMode 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Check if vertex layout has been set.
-- @function [parent=#VertexLayout] isValid 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Set stride of vertices.<br>
-- param stride Specifies the distance between the data of two vertices, in bytes.
-- @function [parent=#VertexLayout] setLayout 
-- @param self
-- @param #unsigned int stride
-- @return backend::VertexLayout#backend::VertexLayout self (return value: cc.backend::VertexLayout)
        
--------------------------------
-- Set attribute values to name.<br>
-- param name Specifies the attribute name.<br>
-- param index Specifies the index of the generic vertex attribute to be modified.<br>
-- param format Specifies how the vertex attribute data is laid out in memory.<br>
-- param offset Specifies the byte offset to the first component of the first generic vertex attribute.<br>
-- param needToBeNormallized Specifies whether fixed-point data values should be normalized (true) or converted directly as fixed-point values (false) when they are accessed.
-- @function [parent=#VertexLayout] setAttribute 
-- @param self
-- @param #string name
-- @param #unsigned int index
-- @param #int format
-- @param #unsigned int offset
-- @param #bool needToBeNormallized
-- @return backend::VertexLayout#backend::VertexLayout self (return value: cc.backend::VertexLayout)
        
--------------------------------
-- Get the distance between the data of two vertices, in bytes.<br>
-- return The distance between the data of two vertices, in bytes.
-- @function [parent=#VertexLayout] getStride 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#VertexLayout] VertexLayout 
-- @param self
-- @return backend::VertexLayout#backend::VertexLayout self (return value: cc.backend::VertexLayout)
        
return nil
