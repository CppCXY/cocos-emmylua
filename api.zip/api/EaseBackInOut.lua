
--------------------------------
-- @module EaseBackInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseBackInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBackInOut#EaseBackInOut ret (return value: cc.EaseBackInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBackInOut] clone 
-- @param self
-- @return EaseBackInOut#EaseBackInOut ret (return value: cc.EaseBackInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBackInOut] update 
-- @param self
-- @param #float time
-- @return EaseBackInOut#EaseBackInOut self (return value: cc.EaseBackInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBackInOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseBackInOut] EaseBackInOut 
-- @param self
-- @return EaseBackInOut#EaseBackInOut self (return value: cc.EaseBackInOut)
        
return nil
