
--------------------------------
-- @module EventKeyboard
-- @extend Event
-- @parent_module cc

--------------------------------
--  Constructor.<br>
-- param keyCode A given keycode.<br>
-- param isPressed True if the key is pressed.<br>
-- js ctor
-- @function [parent=#EventKeyboard] EventKeyboard 
-- @param self
-- @param #int keyCode
-- @param #bool isPressed
-- @return EventKeyboard#EventKeyboard self (return value: cc.EventKeyboard)
        
return nil
