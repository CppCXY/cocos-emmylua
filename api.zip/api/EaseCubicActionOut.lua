
--------------------------------
-- @module EaseCubicActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseCubicActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseCubicActionOut#EaseCubicActionOut ret (return value: cc.EaseCubicActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionOut] clone 
-- @param self
-- @return EaseCubicActionOut#EaseCubicActionOut ret (return value: cc.EaseCubicActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionOut] update 
-- @param self
-- @param #float time
-- @return EaseCubicActionOut#EaseCubicActionOut self (return value: cc.EaseCubicActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionOut] EaseCubicActionOut 
-- @param self
-- @return EaseCubicActionOut#EaseCubicActionOut self (return value: cc.EaseCubicActionOut)
        
return nil
