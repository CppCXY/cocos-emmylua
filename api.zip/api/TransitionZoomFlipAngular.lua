
--------------------------------
-- @module TransitionZoomFlipAngular
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionZoomFlipAngular] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionZoomFlipAngular#TransitionZoomFlipAngular ret (return value: cc.TransitionZoomFlipAngular)

--------------------------------
-- 
-- @function [parent=#TransitionZoomFlipAngular] TransitionZoomFlipAngular 
-- @param self
-- @return TransitionZoomFlipAngular#TransitionZoomFlipAngular self (return value: cc.TransitionZoomFlipAngular)
        
return nil
