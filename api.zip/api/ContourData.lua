
--------------------------------
-- @module ContourData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ContourData] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ContourData] addVertex 
-- @param self
-- @param #vec2_table vertex
-- @return ContourData#ContourData self (return value: ccs.ContourData)
        
--------------------------------
-- 
-- @function [parent=#ContourData] create 
-- @param self
-- @return ContourData#ContourData ret (return value: ccs.ContourData)
        
--------------------------------
-- js ctor
-- @function [parent=#ContourData] ContourData 
-- @param self
-- @return ContourData#ContourData self (return value: ccs.ContourData)
        
return nil
