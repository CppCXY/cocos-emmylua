
--------------------------------
-- @module ArmatureDisplayData
-- @extend DisplayData
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ArmatureDisplayData] create 
-- @param self
-- @return ArmatureDisplayData#ArmatureDisplayData ret (return value: ccs.ArmatureDisplayData)
        
--------------------------------
-- js ctor
-- @function [parent=#ArmatureDisplayData] ArmatureDisplayData 
-- @param self
-- @return ArmatureDisplayData#ArmatureDisplayData self (return value: ccs.ArmatureDisplayData)
        
return nil
