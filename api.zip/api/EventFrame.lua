
--------------------------------
-- @module EventFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#EventFrame] setEvent 
-- @param self
-- @param #string event
-- @return EventFrame#EventFrame self (return value: ccs.EventFrame)
        
--------------------------------
-- 
-- @function [parent=#EventFrame] init 
-- @param self
-- @return EventFrame#EventFrame self (return value: ccs.EventFrame)
        
--------------------------------
-- 
-- @function [parent=#EventFrame] getEvent 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#EventFrame] create 
-- @param self
-- @return EventFrame#EventFrame ret (return value: ccs.EventFrame)
        
--------------------------------
-- 
-- @function [parent=#EventFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#EventFrame] setNode 
-- @param self
-- @param #cc.Node node
-- @return EventFrame#EventFrame self (return value: ccs.EventFrame)
        
--------------------------------
-- 
-- @function [parent=#EventFrame] EventFrame 
-- @param self
-- @return EventFrame#EventFrame self (return value: ccs.EventFrame)
        
return nil
