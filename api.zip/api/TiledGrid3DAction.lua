
--------------------------------
-- @module TiledGrid3DAction
-- @extend GridAction
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TiledGrid3DAction] clone 
-- @param self
-- @return TiledGrid3DAction#TiledGrid3DAction ret (return value: cc.TiledGrid3DAction)
        
--------------------------------
--  returns the grid 
-- @function [parent=#TiledGrid3DAction] getGrid 
-- @param self
-- @return GridBase#GridBase ret (return value: cc.GridBase)
        
return nil
