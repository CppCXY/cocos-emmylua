
--------------------------------
-- @module ControlColourPicker
-- @extend Control
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ControlColourPicker] hueSliderValueChanged 
-- @param self
-- @param #cc.Ref sender
-- @param #int controlEvent
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] getHuePicker 
-- @param self
-- @return ControlHuePicker#ControlHuePicker ret (return value: cc.ControlHuePicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] getcolourPicker 
-- @param self
-- @return ControlSaturationBrightnessPicker#ControlSaturationBrightnessPicker ret (return value: cc.ControlSaturationBrightnessPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setBackground 
-- @param self
-- @param #cc.Sprite var
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setcolourPicker 
-- @param self
-- @param #cc.ControlSaturationBrightnessPicker var
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] colourSliderValueChanged 
-- @param self
-- @param #cc.Ref sender
-- @param #int controlEvent
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setHuePicker 
-- @param self
-- @param #cc.ControlHuePicker var
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] getBackground 
-- @param self
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] create 
-- @param self
-- @return ControlColourPicker#ControlColourPicker ret (return value: cc.ControlColourPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setEnabled 
-- @param self
-- @param #bool bEnabled
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setColor 
-- @param self
-- @param #color3b_table colorValue
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
--------------------------------
-- js ctor<br>
-- lua new
-- @function [parent=#ControlColourPicker] ControlColourPicker 
-- @param self
-- @return ControlColourPicker#ControlColourPicker self (return value: cc.ControlColourPicker)
        
return nil
