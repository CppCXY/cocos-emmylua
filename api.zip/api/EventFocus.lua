
--------------------------------
-- @module EventFocus
-- @extend Event
-- @parent_module cc

--------------------------------
--  Constructor.<br>
-- param widgetLoseFocus The widget which lose focus.<br>
-- param widgetGetFocus The widget which get focus.<br>
-- js ctor
-- @function [parent=#EventFocus] EventFocus 
-- @param self
-- @param #ccui.Widget widgetLoseFocus
-- @param #ccui.Widget widgetGetFocus
-- @return EventFocus#EventFocus self (return value: cc.EventFocus)
        
return nil
