
--------------------------------
-- @module ProgramState
-- @extend Ref
-- @parent_module ccb

--------------------------------
-- Set texture.<br>
-- param uniformLocation Specifies texture location.<br>
-- param slot Specifies texture slot selector.<br>
-- param texture Specifies a pointer to backend texture.
-- @function [parent=#ProgramState] setTexture 
-- @param self
-- @param #cc.backend::UniformLocation uniformLocation
-- @param #unsigned int slot
-- @param #cc.backend::TextureBackend texture
-- @return backend::ProgramState#backend::ProgramState self (return value: cc.backend::ProgramState)
        
--------------------------------
-- Deep clone ProgramState
-- @function [parent=#ProgramState] clone 
-- @param self
-- @return backend::ProgramState#backend::ProgramState ret (return value: cc.backend::ProgramState)
        
--------------------------------
-- Sets a uniform auto-binding.<br>
-- This method parses the passed in autoBinding string and attempts to convert it<br>
-- to an enumeration value. If it matches to one of the predefined strings, it will create a<br>
-- callback to get the correct value at runtime.<br>
-- param uniformName The name of the material parameter to store an auto-binding for.<br>
-- param autoBinding A string matching one of the built-in AutoBinding enum constants.
-- @function [parent=#ProgramState] setParameterAutoBinding 
-- @param self
-- @param #string uniformName
-- @param #string autoBinding
-- @return backend::ProgramState#backend::ProgramState self (return value: cc.backend::ProgramState)
        
--------------------------------
-- Get the program object.
-- @function [parent=#ProgramState] getProgram 
-- @param self
-- @return backend::Program#backend::Program ret (return value: cc.backend::Program)
        
--------------------------------
-- @overload self, int         
-- @overload self, string         
-- @function [parent=#ProgramState] getAttributeLocation
-- @param self
-- @param #string name
-- @return int#int ret (return value: int)

--------------------------------
-- param program Specifies the program.
-- @function [parent=#ProgramState] ProgramState 
-- @param self
-- @param #cc.backend::Program program
-- @return backend::ProgramState#backend::ProgramState self (return value: cc.backend::ProgramState)
        
return nil
