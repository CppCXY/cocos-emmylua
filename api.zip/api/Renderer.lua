
--------------------------------
-- @module Renderer
-- @parent_module cc

--------------------------------
-- Get winding mode.<br>
-- return The winding mode.
-- @function [parent=#Renderer] getWinding 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#Renderer] getDrawnVertices 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Renders into the GLView all the queued `RenderCommand` objects 
-- @function [parent=#Renderer] render 
-- @param self
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
--  Creates a render queue and returns its Id 
-- @function [parent=#Renderer] createRenderQueue 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get whether stencil test is enabled or not.<br>
-- return true if stencil test is enabled, false otherwise.
-- @function [parent=#Renderer] getStencilTest 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Get the render target flag.<br>
-- return The render target flag.
-- @function [parent=#Renderer] getRenderTargetFlag 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get the clear flag.<br>
-- return The clear flag.
-- @function [parent=#Renderer] getClearFlag 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get stencil reference value set by `setStencilCompareFunction`. <br>
-- return Stencil reference value.<br>
-- see `setStencilCompareFunction(backend::CompareFunction func, unsigned int ref, unsigned int readMask)`
-- @function [parent=#Renderer] getStencilReferenceValue 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- Get stencil attachment.<br>
-- return Stencil attachment.
-- @function [parent=#Renderer] getStencilAttachment 
-- @param self
-- @return Texture2D#Texture2D ret (return value: cc.Texture2D)
        
--------------------------------
-- Fixed-function state<br>
-- param x The x coordinate of the upper-left corner of the viewport.<br>
-- param y The y coordinate of the upper-left corner of the viewport.<br>
-- param w The width of the viewport, in pixels.<br>
-- param h The height of the viewport, in pixels.
-- @function [parent=#Renderer] setViewPort 
-- @param self
-- @param #int x
-- @param #int y
-- @param #unsigned int w
-- @param #unsigned int h
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Get the stencil readMask.<br>
-- return Stencil read mask.<br>
-- see `setStencilCompareFunction(backend::CompareFunction func, unsigned int ref, unsigned int readMask)`
-- @function [parent=#Renderer] getStencilReadMask 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- Get depth clear value.<br>
-- return Depth clear value. 
-- @function [parent=#Renderer] getClearDepth 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- Set front and back function and reference value for stencil testing.<br>
-- param func Specifies the stencil test function.<br>
-- param ref Specifies the reference value for the stencil test. <br>
-- readMask Specifies a mask that is ANDed with both the reference value and the stored stencil value when the test is done. 
-- @function [parent=#Renderer] setStencilCompareFunction 
-- @param self
-- @param #int func
-- @param #unsigned int ref
-- @param #unsigned int readMask
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- / Get viewport.
-- @function [parent=#Renderer] getViewport 
-- @param self
-- @return Viewport#Viewport ret (return value: cc.Viewport)
        
--------------------------------
-- Get the index when the stencil buffer is cleared. <br>
-- return The index used when the stencil buffer is cleared. 
-- @function [parent=#Renderer] getClearStencil 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- Enable/disable stencil test. <br>
-- param value true means enable stencil test, otherwise false.
-- @function [parent=#Renderer] setStencilTest 
-- @param self
-- @param #bool value
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- / Get the action to take when the stencil test fails. 
-- @function [parent=#Renderer] getStencilFailureOperation 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get color attachment.<br>
-- return Color attachment.
-- @function [parent=#Renderer] getColorAttachment 
-- @param self
-- @return Texture2D#Texture2D ret (return value: cc.Texture2D)
        
--------------------------------
-- @overload self, cc.RenderCommand, int         
-- @overload self, cc.RenderCommand         
-- @function [parent=#Renderer] addCommand
-- @param self
-- @param #cc.RenderCommand command
-- @param #int renderQueueID
-- @return Renderer#Renderer self (return value: cc.Renderer)

--------------------------------
-- Enable/disable depth test. <br>
-- param value true means enable depth test, otherwise false.
-- @function [parent=#Renderer] setDepthTest 
-- @param self
-- @param #bool value
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Fixed-function state<br>
-- param x, y Specifies the lower left corner of the scissor box<br>
-- param wdith Specifies the width of the scissor box<br>
-- param height Specifies the height of the scissor box
-- @function [parent=#Renderer] setScissorRect 
-- @param self
-- @param #float x
-- @param #float y
-- @param #float width
-- @param #float height
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Get whether depth test state is enabled or disabled.<br>
-- return true if depth test is enabled, otherwise false.
-- @function [parent=#Renderer] getDepthTest 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Renderer] init 
-- @param self
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Enable/disable to update depth buffer. <br>
-- param value true means enable writing into the depth buffer, otherwise false.
-- @function [parent=#Renderer] setDepthWrite 
-- @param self
-- @param #bool value
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- / Get the stencil action when the stencil test passes, but the depth test fails. 
-- @function [parent=#Renderer] getStencilPassDepthFailureOperation 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Fixed-function state<br>
-- param mode Controls if primitives are culled when front facing, back facing, or not culled at all.
-- @function [parent=#Renderer] setCullMode 
-- @param self
-- @param #int mode
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
--  Pops a group from the render queue 
-- @function [parent=#Renderer] popGroup 
-- @param self
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
--  Pushes a group into the render queue 
-- @function [parent=#Renderer] pushGroup 
-- @param self
-- @param #int renderQueueID
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- 
-- @function [parent=#Renderer] getScissorRect 
-- @param self
-- @return ScissorRect#ScissorRect ret (return value: cc.ScissorRect)
        
--------------------------------
-- 
-- @function [parent=#Renderer] getScissorTest 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Get the stencil write mask.<br>
-- return Stencil write mask.<br>
-- see `setStencilWriteMask(unsigned int mask)`
-- @function [parent=#Renderer] getStencilWriteMask 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#Renderer] addDrawnBatches 
-- @param self
-- @param #int number
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
--  returns whether or not a rectangle is visible or not 
-- @function [parent=#Renderer] checkVisibility 
-- @param self
-- @param #mat4_table transform
-- @param #size_table size
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Set front and back stencil test actions.<br>
-- param stencilFailureOp Specifies the action to take when the stencil test fails. <br>
-- param depthFailureOp Specifies the stencil action when the stencil test passes, but the depth test fails. <br>
-- param stencilDepthPassOp Specifies the stencil action when both the stencil test and the depth test pass, or when the stencil test passes and either there is no depth buffer or depth testing is not enabled. 
-- @function [parent=#Renderer] setStencilOperation 
-- @param self
-- @param #int stencilFailureOp
-- @param #int depthFailureOp
-- @param #int stencilDepthPassOp
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Get whether writing to depth buffer is enabled or not.<br>
-- return true if enable writing into the depth buffer, false otherwise.
-- @function [parent=#Renderer] getDepthWrite 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Get cull mode.<br>
-- return The cull mode.
-- @function [parent=#Renderer] getCullMode 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- / Get the stencil test function.
-- @function [parent=#Renderer] getStencilCompareFunction 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Get color clear value.<br>
-- return Color clear value.
-- @function [parent=#Renderer] getClearColor 
-- @param self
-- @return color4f_table#color4f_table ret (return value: color4f_table)
        
--------------------------------
-- Set depth compare function.<br>
-- param func Specifies the value used for depth buffer comparisons.
-- @function [parent=#Renderer] setDepthCompareFunction 
-- @param self
-- @param #int func
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Control the front and back writing of individual bits in the stencil planes.<br>
-- param mask Specifies a bit mask to enable and disable writing of individual bits in the stencil planes.
-- @function [parent=#Renderer] setStencilWriteMask 
-- @param self
-- @param #unsigned int mask
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- / Get the stencil action when both the stencil test and the depth test pass, or when the stencil test passes and either there is no depth buffer or depth testing is not enabled. 
-- @function [parent=#Renderer] getStencilDepthPassOperation 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Enable/disable scissor test. <br>
-- param enabled true if enable scissor test, false otherwise.
-- @function [parent=#Renderer] setScissorTest 
-- @param self
-- @param #bool enabled
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Fixed-function state<br>
-- param winding The winding order of front-facing primitives.
-- @function [parent=#Renderer] setWinding 
-- @param self
-- @param #int winding
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Set clear values for each attachment.<br>
-- flags Flags to indicate which attachment clear value to be modified.<br>
-- color The clear color value.<br>
-- depth The clear depth value.<br>
-- stencil The clear stencil value.
-- @function [parent=#Renderer] clear 
-- @param self
-- @param #int flags
-- @param #color4f_table color
-- @param #float depth
-- @param #unsigned int stencil
-- @param #float globalOrder
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Set render targets. If not set, will use default render targets. It will effect all commands.<br>
-- flags Flags to indicate which attachment to be replaced.<br>
-- colorAttachment The value to replace color attachment, only one color attachment supported now.<br>
-- depthAttachment The value to repalce depth attachment.<br>
-- stencilAttachment The value to replace stencil attachment. Depth attachment and stencil attachment<br>
-- can be the same value.
-- @function [parent=#Renderer] setRenderTarget 
-- @param self
-- @param #int flags
-- @param #cc.Texture2D colorAttachment
-- @param #cc.Texture2D depthAttachment
-- @param #cc.Texture2D stencilAttachment
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Get depth attachment.<br>
-- return Depth attachment.
-- @function [parent=#Renderer] getDepthAttachment 
-- @param self
-- @return Texture2D#Texture2D ret (return value: cc.Texture2D)
        
--------------------------------
-- 
-- @function [parent=#Renderer] addDrawnVertices 
-- @param self
-- @param #int number
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
--  Cleans all `RenderCommand`s in the queue 
-- @function [parent=#Renderer] clean 
-- @param self
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- 
-- @function [parent=#Renderer] getDrawnBatches 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#Renderer] clearDrawStats 
-- @param self
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
--------------------------------
-- Get depth compare function.<br>
-- return Depth compare function.
-- @function [parent=#Renderer] getDepthCompareFunction 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Constructor.
-- @function [parent=#Renderer] Renderer 
-- @param self
-- @return Renderer#Renderer self (return value: cc.Renderer)
        
return nil
