
--------------------------------
-- @module VBox
-- @extend Layout
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#VBox] initWithSize 
-- @param self
-- @param #size_table size
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @overload self, size_table         
-- @overload self         
-- @function [parent=#VBox] create
-- @param self
-- @param #size_table size
-- @return VBox#VBox ret (return value: ccui.VBox)

--------------------------------
-- 
-- @function [parent=#VBox] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Default constructor<br>
-- js ctor<br>
-- lua new
-- @function [parent=#VBox] VBox 
-- @param self
-- @return VBox#VBox self (return value: ccui.VBox)
        
return nil
