
--------------------------------
-- @module ColorFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ColorFrame] getColor 
-- @param self
-- @return color3b_table#color3b_table ret (return value: color3b_table)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] setColor 
-- @param self
-- @param #color3b_table color
-- @return ColorFrame#ColorFrame self (return value: ccs.ColorFrame)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] create 
-- @param self
-- @return ColorFrame#ColorFrame ret (return value: ccs.ColorFrame)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] ColorFrame 
-- @param self
-- @return ColorFrame#ColorFrame self (return value: ccs.ColorFrame)
        
return nil
