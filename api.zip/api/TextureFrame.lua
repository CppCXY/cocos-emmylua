
--------------------------------
-- @module TextureFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#TextureFrame] getTextureName 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#TextureFrame] setTextureName 
-- @param self
-- @param #string textureName
-- @return TextureFrame#TextureFrame self (return value: ccs.TextureFrame)
        
--------------------------------
-- 
-- @function [parent=#TextureFrame] create 
-- @param self
-- @return TextureFrame#TextureFrame ret (return value: ccs.TextureFrame)
        
--------------------------------
-- 
-- @function [parent=#TextureFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#TextureFrame] setNode 
-- @param self
-- @param #cc.Node node
-- @return TextureFrame#TextureFrame self (return value: ccs.TextureFrame)
        
--------------------------------
-- 
-- @function [parent=#TextureFrame] TextureFrame 
-- @param self
-- @return TextureFrame#TextureFrame self (return value: ccs.TextureFrame)
        
return nil
