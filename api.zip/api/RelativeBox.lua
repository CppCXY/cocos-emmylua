
--------------------------------
-- @module RelativeBox
-- @extend Layout
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#RelativeBox] initWithSize 
-- @param self
-- @param #size_table size
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @overload self, size_table         
-- @overload self         
-- @function [parent=#RelativeBox] create
-- @param self
-- @param #size_table size
-- @return RelativeBox#RelativeBox ret (return value: ccui.RelativeBox)

--------------------------------
-- 
-- @function [parent=#RelativeBox] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Default constructor.<br>
-- js ctor<br>
-- lua new
-- @function [parent=#RelativeBox] RelativeBox 
-- @param self
-- @return RelativeBox#RelativeBox self (return value: ccui.RelativeBox)
        
return nil
