
--------------------------------
-- @module EventCustom
-- @extend Event
-- @parent_module cc

--------------------------------
--  Gets event name.<br>
-- return The name of the event.
-- @function [parent=#EventCustom] getEventName 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
--  Constructor.<br>
-- param eventName A given name of the custom event.<br>
-- js ctor
-- @function [parent=#EventCustom] EventCustom 
-- @param self
-- @param #string eventName
-- @return EventCustom#EventCustom self (return value: cc.EventCustom)
        
return nil
