
--------------------------------
-- @module InnerActionFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#InnerActionFrame] getEndFrameIndex 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] getStartFrameIndex 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] getInnerActionType 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] setEndFrameIndex 
-- @param self
-- @param #int frameIndex
-- @return InnerActionFrame#InnerActionFrame self (return value: ccs.InnerActionFrame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] setEnterWithName 
-- @param self
-- @param #bool isEnterWithName
-- @return InnerActionFrame#InnerActionFrame self (return value: ccs.InnerActionFrame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] setSingleFrameIndex 
-- @param self
-- @param #int frameIndex
-- @return InnerActionFrame#InnerActionFrame self (return value: ccs.InnerActionFrame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] setStartFrameIndex 
-- @param self
-- @param #int frameIndex
-- @return InnerActionFrame#InnerActionFrame self (return value: ccs.InnerActionFrame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] getSingleFrameIndex 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] setInnerActionType 
-- @param self
-- @param #int type
-- @return InnerActionFrame#InnerActionFrame self (return value: ccs.InnerActionFrame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] setAnimationName 
-- @param self
-- @param #string animationNamed
-- @return InnerActionFrame#InnerActionFrame self (return value: ccs.InnerActionFrame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] create 
-- @param self
-- @return InnerActionFrame#InnerActionFrame ret (return value: ccs.InnerActionFrame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#InnerActionFrame] InnerActionFrame 
-- @param self
-- @return InnerActionFrame#InnerActionFrame self (return value: ccs.InnerActionFrame)
        
return nil
