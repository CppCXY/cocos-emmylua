
--------------------------------
-- @module FlipX
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  init the action 
-- @function [parent=#FlipX] initWithFlipX 
-- @param self
-- @param #bool x
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Create the action.<br>
-- param x Flips the sprite horizontally if true.<br>
-- return  An autoreleased FlipX object.
-- @function [parent=#FlipX] create 
-- @param self
-- @param #bool x
-- @return FlipX#FlipX ret (return value: cc.FlipX)
        
--------------------------------
-- 
-- @function [parent=#FlipX] clone 
-- @param self
-- @return FlipX#FlipX ret (return value: cc.FlipX)
        
--------------------------------
-- param time In seconds.
-- @function [parent=#FlipX] update 
-- @param self
-- @param #float time
-- @return FlipX#FlipX self (return value: cc.FlipX)
        
--------------------------------
-- 
-- @function [parent=#FlipX] reverse 
-- @param self
-- @return FlipX#FlipX ret (return value: cc.FlipX)
        
--------------------------------
-- 
-- @function [parent=#FlipX] FlipX 
-- @param self
-- @return FlipX#FlipX self (return value: cc.FlipX)
        
return nil
