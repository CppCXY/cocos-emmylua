
--------------------------------
-- @module BlendFuncFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#BlendFuncFrame] getBlendFunc 
-- @param self
-- @return BlendFunc#BlendFunc ret (return value: cc.BlendFunc)
        
--------------------------------
-- 
-- @function [parent=#BlendFuncFrame] setBlendFunc 
-- @param self
-- @param #cc.BlendFunc blendFunc
-- @return BlendFuncFrame#BlendFuncFrame self (return value: ccs.BlendFuncFrame)
        
--------------------------------
-- 
-- @function [parent=#BlendFuncFrame] create 
-- @param self
-- @return BlendFuncFrame#BlendFuncFrame ret (return value: ccs.BlendFuncFrame)
        
--------------------------------
-- 
-- @function [parent=#BlendFuncFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#BlendFuncFrame] BlendFuncFrame 
-- @param self
-- @return BlendFuncFrame#BlendFuncFrame self (return value: ccs.BlendFuncFrame)
        
return nil
