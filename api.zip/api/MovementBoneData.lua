
--------------------------------
-- @module MovementBoneData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#MovementBoneData] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#MovementBoneData] getFrameData 
-- @param self
-- @param #int index
-- @return FrameData#FrameData ret (return value: ccs.FrameData)
        
--------------------------------
-- 
-- @function [parent=#MovementBoneData] addFrameData 
-- @param self
-- @param #ccs.FrameData frameData
-- @return MovementBoneData#MovementBoneData self (return value: ccs.MovementBoneData)
        
--------------------------------
-- 
-- @function [parent=#MovementBoneData] create 
-- @param self
-- @return MovementBoneData#MovementBoneData ret (return value: ccs.MovementBoneData)
        
--------------------------------
-- js ctor
-- @function [parent=#MovementBoneData] MovementBoneData 
-- @param self
-- @return MovementBoneData#MovementBoneData self (return value: ccs.MovementBoneData)
        
return nil
