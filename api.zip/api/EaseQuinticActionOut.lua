
--------------------------------
-- @module EaseQuinticActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuinticActionOut#EaseQuinticActionOut ret (return value: cc.EaseQuinticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] clone 
-- @param self
-- @return EaseQuinticActionOut#EaseQuinticActionOut ret (return value: cc.EaseQuinticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] update 
-- @param self
-- @param #float time
-- @return EaseQuinticActionOut#EaseQuinticActionOut self (return value: cc.EaseQuinticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] EaseQuinticActionOut 
-- @param self
-- @return EaseQuinticActionOut#EaseQuinticActionOut self (return value: cc.EaseQuinticActionOut)
        
return nil
