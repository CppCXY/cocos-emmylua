
--------------------------------
-- @module EaseQuadraticActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuadraticActionOut#EaseQuadraticActionOut ret (return value: cc.EaseQuadraticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] clone 
-- @param self
-- @return EaseQuadraticActionOut#EaseQuadraticActionOut ret (return value: cc.EaseQuadraticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] update 
-- @param self
-- @param #float time
-- @return EaseQuadraticActionOut#EaseQuadraticActionOut self (return value: cc.EaseQuadraticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] EaseQuadraticActionOut 
-- @param self
-- @return EaseQuadraticActionOut#EaseQuadraticActionOut self (return value: cc.EaseQuadraticActionOut)
        
return nil
