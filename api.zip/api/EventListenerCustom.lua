
--------------------------------
-- @module EventListenerCustom
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerCustom] clone 
-- @param self
-- @return EventListenerCustom#EventListenerCustom ret (return value: cc.EventListenerCustom)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerCustom] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Constructor 
-- @function [parent=#EventListenerCustom] EventListenerCustom 
-- @param self
-- @return EventListenerCustom#EventListenerCustom self (return value: cc.EventListenerCustom)
        
return nil
