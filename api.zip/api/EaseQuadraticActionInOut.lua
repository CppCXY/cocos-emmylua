
--------------------------------
-- @module EaseQuadraticActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuadraticActionInOut#EaseQuadraticActionInOut ret (return value: cc.EaseQuadraticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] clone 
-- @param self
-- @return EaseQuadraticActionInOut#EaseQuadraticActionInOut ret (return value: cc.EaseQuadraticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] update 
-- @param self
-- @param #float time
-- @return EaseQuadraticActionInOut#EaseQuadraticActionInOut self (return value: cc.EaseQuadraticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] EaseQuadraticActionInOut 
-- @param self
-- @return EaseQuadraticActionInOut#EaseQuadraticActionInOut self (return value: cc.EaseQuadraticActionInOut)
        
return nil
