
--------------------------------
-- @module HBox
-- @extend Layout
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#HBox] initWithSize 
-- @param self
-- @param #size_table size
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @overload self, size_table         
-- @overload self         
-- @function [parent=#HBox] create
-- @param self
-- @param #size_table size
-- @return HBox#HBox ret (return value: ccui.HBox)

--------------------------------
-- 
-- @function [parent=#HBox] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- Default constructor<br>
-- js ctor<br>
-- lua new
-- @function [parent=#HBox] HBox 
-- @param self
-- @return HBox#HBox self (return value: ccui.HBox)
        
return nil
