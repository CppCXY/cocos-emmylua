
--------------------------------
-- @module EventListenerAcceleration
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerAcceleration] init 
-- @param self
-- @param #function callback
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerAcceleration] clone 
-- @param self
-- @return EventListenerAcceleration#EventListenerAcceleration ret (return value: cc.EventListenerAcceleration)
        
--------------------------------
-- 
-- @function [parent=#EventListenerAcceleration] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#EventListenerAcceleration] EventListenerAcceleration 
-- @param self
-- @return EventListenerAcceleration#EventListenerAcceleration self (return value: cc.EventListenerAcceleration)
        
return nil
