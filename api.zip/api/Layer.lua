
--------------------------------
-- @module Layer
-- @extend Node
-- @parent_module cc

--------------------------------
--  Creates a fullscreen black layer.<br>
-- return An autoreleased Layer object.
-- @function [parent=#Layer] create 
-- @param self
-- @return Layer#Layer ret (return value: cc.Layer)
        
--------------------------------
-- 
-- @function [parent=#Layer] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Layer] getDescription 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#Layer] Layer 
-- @param self
-- @return Layer#Layer self (return value: cc.Layer)
        
return nil
