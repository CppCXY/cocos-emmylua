
--------------------------------
-- @module EaseBounceOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseBounceOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBounceOut#EaseBounceOut ret (return value: cc.EaseBounceOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceOut] clone 
-- @param self
-- @return EaseBounceOut#EaseBounceOut ret (return value: cc.EaseBounceOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceOut] update 
-- @param self
-- @param #float time
-- @return EaseBounceOut#EaseBounceOut self (return value: cc.EaseBounceOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceOut] EaseBounceOut 
-- @param self
-- @return EaseBounceOut#EaseBounceOut self (return value: cc.EaseBounceOut)
        
return nil
