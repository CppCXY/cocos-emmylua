
--------------------------------
-- @module PhysicsJointPin
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointPin] createConstraints 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @overload self, cc.PhysicsBody, cc.PhysicsBody, vec2_table, vec2_table         
-- @overload self, cc.PhysicsBody, cc.PhysicsBody, vec2_table         
-- @function [parent=#PhysicsJointPin] construct
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #vec2_table anchr1
-- @param #vec2_table anchr2
-- @return PhysicsJointPin#PhysicsJointPin ret (return value: cc.PhysicsJointPin)

return nil
