
--------------------------------
-- @module FrameData
-- @extend BaseData
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#FrameData] copy 
-- @param self
-- @param #ccs.BaseData baseData
-- @return FrameData#FrameData self (return value: ccs.FrameData)
        
--------------------------------
-- 
-- @function [parent=#FrameData] create 
-- @param self
-- @return FrameData#FrameData ret (return value: ccs.FrameData)
        
--------------------------------
-- js ctor
-- @function [parent=#FrameData] FrameData 
-- @param self
-- @return FrameData#FrameData self (return value: ccs.FrameData)
        
return nil
