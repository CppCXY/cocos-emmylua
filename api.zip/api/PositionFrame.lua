
--------------------------------
-- @module PositionFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#PositionFrame] getX 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] getY 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] setPosition 
-- @param self
-- @param #vec2_table position
-- @return PositionFrame#PositionFrame self (return value: ccs.PositionFrame)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] setX 
-- @param self
-- @param #float x
-- @return PositionFrame#PositionFrame self (return value: ccs.PositionFrame)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] setY 
-- @param self
-- @param #float y
-- @return PositionFrame#PositionFrame self (return value: ccs.PositionFrame)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] getPosition 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] create 
-- @param self
-- @return PositionFrame#PositionFrame ret (return value: ccs.PositionFrame)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#PositionFrame] PositionFrame 
-- @param self
-- @return PositionFrame#PositionFrame self (return value: ccs.PositionFrame)
        
return nil
