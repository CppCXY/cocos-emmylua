
--------------------------------
-- @module PhysicsContactPostSolve
-- @parent_module cc

--------------------------------
--  Get friction between two bodies.
-- @function [parent=#PhysicsContactPostSolve] getFriction 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
--  Get surface velocity between two bodies.
-- @function [parent=#PhysicsContactPostSolve] getSurfaceVelocity 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
--  Get restitution between two bodies.
-- @function [parent=#PhysicsContactPostSolve] getRestitution 
-- @param self
-- @return float#float ret (return value: float)
        
return nil
