
--------------------------------
-- @module EaseBounceInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBounceInOut#EaseBounceInOut ret (return value: cc.EaseBounceInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] clone 
-- @param self
-- @return EaseBounceInOut#EaseBounceInOut ret (return value: cc.EaseBounceInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] update 
-- @param self
-- @param #float time
-- @return EaseBounceInOut#EaseBounceInOut self (return value: cc.EaseBounceInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] EaseBounceInOut 
-- @param self
-- @return EaseBounceInOut#EaseBounceInOut self (return value: cc.EaseBounceInOut)
        
return nil
