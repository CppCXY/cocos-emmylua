
--------------------------------
-- @module ComController
-- @extend Component,InputDelegate
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ComController] create 
-- @param self
-- @return ComController#ComController ret (return value: ccs.ComController)
        
--------------------------------
-- 
-- @function [parent=#ComController] createInstance 
-- @param self
-- @return Ref#Ref ret (return value: cc.Ref)
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#ComController] onRemove 
-- @param self
-- @return ComController#ComController self (return value: ccs.ComController)
        
--------------------------------
-- 
-- @function [parent=#ComController] update 
-- @param self
-- @param #float delta
-- @return ComController#ComController self (return value: ccs.ComController)
        
--------------------------------
-- 
-- @function [parent=#ComController] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#ComController] onAdd 
-- @param self
-- @return ComController#ComController self (return value: ccs.ComController)
        
--------------------------------
-- js ctor
-- @function [parent=#ComController] ComController 
-- @param self
-- @return ComController#ComController self (return value: ccs.ComController)
        
return nil
