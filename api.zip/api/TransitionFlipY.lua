
--------------------------------
-- @module TransitionFlipY
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionFlipY] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionFlipY#TransitionFlipY ret (return value: cc.TransitionFlipY)

--------------------------------
-- 
-- @function [parent=#TransitionFlipY] TransitionFlipY 
-- @param self
-- @return TransitionFlipY#TransitionFlipY self (return value: cc.TransitionFlipY)
        
return nil
