
--------------------------------
-- @module FastTMXLayer
-- @extend Node
-- @parent_module cc

--------------------------------
--  Returns the position in points of a given tile coordinate.<br>
-- param tileCoordinate The tile Coordinate.<br>
-- return The position in points of a given tile coordinate.
-- @function [parent=#FastTMXLayer] getPositionAt 
-- @param self
-- @param #vec2_table tileCoordinate
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
--  Set Layer orientation, which is the same as the map orientation. <br>
-- param orientation Layer orientation, which is the same as the map orientation.
-- @function [parent=#FastTMXLayer] setLayerOrientation 
-- @param self
-- @param #int orientation
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
--  Size of the layer in tiles.<br>
-- return Size of the layer in tiles.
-- @function [parent=#FastTMXLayer] getLayerSize 
-- @param self
-- @return size_table#size_table ret (return value: size_table)
        
--------------------------------
--  Set the size of the map's tile. <br>
-- param size The new size of the map's tile.
-- @function [parent=#FastTMXLayer] setMapTileSize 
-- @param self
-- @param #size_table size
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
--  Layer orientation, which is the same as the map orientation.<br>
-- return Layer orientation, which is the same as the map orientation.
-- @function [parent=#FastTMXLayer] getLayerOrientation 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Set the properties to the layer.<br>
-- param properties The properties to the layer.
-- @function [parent=#FastTMXLayer] setProperties 
-- @param self
-- @param #map_table properties
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
--  Set the tile layer name.<br>
-- param layerName The new layer name.
-- @function [parent=#FastTMXLayer] setLayerName 
-- @param self
-- @param #string layerName
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
--  Removes a tile at given tile coordinate.<br>
-- param tileCoordinate The tile Coordinate.
-- @function [parent=#FastTMXLayer] removeTileAt 
-- @param self
-- @param #vec2_table tileCoordinate
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
-- @overload self         
-- @overload self         
-- @function [parent=#FastTMXLayer] getProperties
-- @param self
-- @return map_table#map_table ret (return value: map_table)

--------------------------------
--  Creates the tiles. 
-- @function [parent=#FastTMXLayer] setupTiles 
-- @param self
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
--  Set an sprite to the tile,with the tile coordinate and gid.<br>
-- param sprite A Sprite.<br>
-- param pos The tile coordinate.<br>
-- param gid The tile gid.
-- @function [parent=#FastTMXLayer] setupTileSprite 
-- @param self
-- @param #cc.Sprite sprite
-- @param #vec2_table pos
-- @param #unsigned int gid
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
-- @overload self, int, vec2_table, int         
-- @overload self, int, vec2_table         
-- @function [parent=#FastTMXLayer] setTileGID
-- @param self
-- @param #int gid
-- @param #vec2_table tileCoordinate
-- @param #int flags
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)

--------------------------------
--  Size of the map's tile (could be different from the tile's size).<br>
-- return Size of the map's tile (could be different from the tile's size).
-- @function [parent=#FastTMXLayer] getMapTileSize 
-- @param self
-- @return size_table#size_table ret (return value: size_table)
        
--------------------------------
--  Return the value for the specific property name.<br>
-- param propertyName The value for the specific property name.<br>
-- return The value for the specific property name.
-- @function [parent=#FastTMXLayer] getProperty 
-- @param self
-- @param #string propertyName
-- @return Value#Value ret (return value: cc.Value)
        
--------------------------------
--  Set the size of the layer in tiles. <br>
-- param size The new size of the layer in tiles.
-- @function [parent=#FastTMXLayer] setLayerSize 
-- @param self
-- @param #size_table size
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
--  Get the tile layer name.<br>
-- return The tile layer name.
-- @function [parent=#FastTMXLayer] getLayerName 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
--  Set the tileset information for the layer. <br>
-- param info The new tileset information for the layer.
-- @function [parent=#FastTMXLayer] setTileSet 
-- @param self
-- @param #cc.TMXTilesetInfo info
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
--  Tileset information for the layer.<br>
-- return Tileset information for the layer.
-- @function [parent=#FastTMXLayer] getTileSet 
-- @param self
-- @return TMXTilesetInfo#TMXTilesetInfo ret (return value: cc.TMXTilesetInfo)
        
--------------------------------
--  Returns the tile (Sprite) at a given a tile coordinate.<br>
-- The returned Sprite will be already added to the TMXLayer. Don't add it again.<br>
-- The Sprite can be treated like any other Sprite: rotated, scaled, translated, opacity, color, etc.<br>
-- You can remove either by calling:<br>
-- - layer->removeChild(sprite, cleanup);<br>
-- return Returns the tile (Sprite) at a given a tile coordinate.
-- @function [parent=#FastTMXLayer] getTileAt 
-- @param self
-- @param #vec2_table tileCoordinate
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
--  Creates a FastTMXLayer with an tileset info, a layer info and a map info.<br>
-- param tilesetInfo An tileset info.<br>
-- param layerInfo A layer info.<br>
-- param mapInfo A map info.<br>
-- return Return an autorelease object.
-- @function [parent=#FastTMXLayer] create 
-- @param self
-- @param #cc.TMXTilesetInfo tilesetInfo
-- @param #cc.TMXLayerInfo layerInfo
-- @param #cc.TMXMapInfo mapInfo
-- @return FastTMXLayer#FastTMXLayer ret (return value: cc.FastTMXLayer)
        
--------------------------------
-- 
-- @function [parent=#FastTMXLayer] removeChild 
-- @param self
-- @param #cc.Node child
-- @param #bool cleanup
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
-- 
-- @function [parent=#FastTMXLayer] draw 
-- @param self
-- @param #cc.Renderer renderer
-- @param #mat4_table transform
-- @param #unsigned int flags
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
--------------------------------
-- 
-- @function [parent=#FastTMXLayer] getDescription 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- js ctor
-- @function [parent=#FastTMXLayer] FastTMXLayer 
-- @param self
-- @return FastTMXLayer#FastTMXLayer self (return value: cc.FastTMXLayer)
        
return nil
