
--------------------------------
-- @module Sprite3DCache
-- @parent_module cc

--------------------------------
-- remove the SpriteData from Sprite3D by given the specified key
-- @function [parent=#Sprite3DCache] removeSprite3DData 
-- @param self
-- @param #string key
-- @return Sprite3DCache#Sprite3DCache self (return value: cc.Sprite3DCache)
        
--------------------------------
-- remove all the SpriteData from Sprite3D
-- @function [parent=#Sprite3DCache] removeAllSprite3DData 
-- @param self
-- @return Sprite3DCache#Sprite3DCache self (return value: cc.Sprite3DCache)
        
--------------------------------
-- 
-- @function [parent=#Sprite3DCache] destroyInstance 
-- @param self
-- @return Sprite3DCache#Sprite3DCache self (return value: cc.Sprite3DCache)
        
--------------------------------
-- get & destroy
-- @function [parent=#Sprite3DCache] getInstance 
-- @param self
-- @return Sprite3DCache#Sprite3DCache ret (return value: cc.Sprite3DCache)
        
--------------------------------
-- 
-- @function [parent=#Sprite3DCache] Sprite3DCache 
-- @param self
-- @return Sprite3DCache#Sprite3DCache self (return value: cc.Sprite3DCache)
        
return nil
