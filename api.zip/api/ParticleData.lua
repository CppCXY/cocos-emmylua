
--------------------------------
-- @module ParticleData
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleData] release 
-- @param self
-- @return ParticleData#ParticleData self (return value: cc.ParticleData)
        
--------------------------------
-- 
-- @function [parent=#ParticleData] getMaxCount 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#ParticleData] init 
-- @param self
-- @param #int count
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ParticleData] copyParticle 
-- @param self
-- @param #int p1
-- @param #int p2
-- @return ParticleData#ParticleData self (return value: cc.ParticleData)
        
--------------------------------
-- 
-- @function [parent=#ParticleData] ParticleData 
-- @param self
-- @return ParticleData#ParticleData self (return value: cc.ParticleData)
        
return nil
