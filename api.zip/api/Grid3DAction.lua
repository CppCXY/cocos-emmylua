
--------------------------------
-- @module Grid3DAction
-- @extend GridAction
-- @parent_module cc

--------------------------------
-- brief Get the effect grid rect.<br>
-- return Return the effect grid rect.
-- @function [parent=#Grid3DAction] getGridRect 
-- @param self
-- @return rect_table#rect_table ret (return value: rect_table)
        
--------------------------------
-- 
-- @function [parent=#Grid3DAction] clone 
-- @param self
-- @return Grid3DAction#Grid3DAction ret (return value: cc.Grid3DAction)
        
--------------------------------
-- 
-- @function [parent=#Grid3DAction] getGrid 
-- @param self
-- @return GridBase#GridBase ret (return value: cc.GridBase)
        
return nil
