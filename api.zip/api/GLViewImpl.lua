
--------------------------------
-- @module GLViewImpl
-- @extend GLView
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#GLViewImpl] createWithRect 
-- @param self
-- @param #string viewName
-- @param #rect_table rect
-- @param #float frameZoomFactor
-- @return GLViewImpl#GLViewImpl ret (return value: cc.GLViewImpl)
        
--------------------------------
-- 
-- @function [parent=#GLViewImpl] create 
-- @param self
-- @param #string viewname
-- @return GLViewImpl#GLViewImpl ret (return value: cc.GLViewImpl)
        
--------------------------------
-- 
-- @function [parent=#GLViewImpl] createWithFullScreen 
-- @param self
-- @param #string viewName
-- @return GLViewImpl#GLViewImpl ret (return value: cc.GLViewImpl)
        
--------------------------------
-- 
-- @function [parent=#GLViewImpl] setIMEKeyboardState 
-- @param self
-- @param #bool bOpen
-- @return GLViewImpl#GLViewImpl self (return value: cc.GLViewImpl)
        
--------------------------------
-- 
-- @function [parent=#GLViewImpl] isOpenGLReady 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#GLViewImpl] getSafeAreaRect 
-- @param self
-- @return rect_table#rect_table ret (return value: rect_table)
        
return nil
