
--------------------------------
-- @module EaseInOut
-- @extend EaseRateAction
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @param #float rate
-- @return EaseInOut#EaseInOut ret (return value: cc.EaseInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseInOut] clone 
-- @param self
-- @return EaseInOut#EaseInOut ret (return value: cc.EaseInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseInOut] update 
-- @param self
-- @param #float time
-- @return EaseInOut#EaseInOut self (return value: cc.EaseInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseInOut] reverse 
-- @param self
-- @return EaseRateAction#EaseRateAction ret (return value: cc.EaseRateAction)
        
--------------------------------
-- 
-- @function [parent=#EaseInOut] EaseInOut 
-- @param self
-- @return EaseInOut#EaseInOut self (return value: cc.EaseInOut)
        
return nil
