
--------------------------------
-- @module ComRender
-- @extend Component
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ComRender] setNode 
-- @param self
-- @param #cc.Node node
-- @return ComRender#ComRender self (return value: ccs.ComRender)
        
--------------------------------
-- 
-- @function [parent=#ComRender] getNode 
-- @param self
-- @return Node#Node ret (return value: cc.Node)
        
--------------------------------
-- @overload self, cc.Node, char         
-- @overload self         
-- @function [parent=#ComRender] create
-- @param self
-- @param #cc.Node node
-- @param #char comName
-- @return ComRender#ComRender ret (return value: ccs.ComRender)

--------------------------------
-- 
-- @function [parent=#ComRender] createInstance 
-- @param self
-- @return Ref#Ref ret (return value: cc.Ref)
        
--------------------------------
-- 
-- @function [parent=#ComRender] serialize 
-- @param self
-- @param #void r
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#ComRender] onRemove 
-- @param self
-- @return ComRender#ComRender self (return value: ccs.ComRender)
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#ComRender] onAdd 
-- @param self
-- @return ComRender#ComRender self (return value: ccs.ComRender)
        
return nil
