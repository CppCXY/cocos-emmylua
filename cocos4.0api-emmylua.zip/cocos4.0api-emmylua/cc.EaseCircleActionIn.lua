
---@class cc.EaseCircleActionIn :cc.ActionEase
local EaseCircleActionIn={ }
cc.EaseCircleActionIn=EaseCircleActionIn




---* 
---@param action cc.ActionInterval
---@return self
function EaseCircleActionIn:create (action) end
---* 
---@return self
function EaseCircleActionIn:clone () end
---* 
---@param time float
---@return self
function EaseCircleActionIn:update (time) end
---* 
---@return cc.ActionEase
function EaseCircleActionIn:reverse () end
---* 
---@return self
function EaseCircleActionIn:EaseCircleActionIn () end