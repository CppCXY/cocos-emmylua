
---@class cc.TransitionFlipX :cc.TransitionSceneOriented
local TransitionFlipX={ }
cc.TransitionFlipX=TransitionFlipX




---@overload fun(float:float,cc.Scene:cc.Scene):self
---@overload fun(float:float,cc.Scene:cc.Scene,int:int):self
---@param t float
---@param s cc.Scene
---@param o int
---@return self
function TransitionFlipX:create (t,s,o) end
---* 
---@return self
function TransitionFlipX:TransitionFlipX () end