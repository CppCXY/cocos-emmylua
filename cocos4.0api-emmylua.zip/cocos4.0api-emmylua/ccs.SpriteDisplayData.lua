
---@class ccs.SpriteDisplayData :ccs.DisplayData
local SpriteDisplayData={ }
ccs.SpriteDisplayData=SpriteDisplayData




---* 
---@param displayData ccs.DisplayData
---@return self
function SpriteDisplayData:copy (displayData) end
---* 
---@return self
function SpriteDisplayData:create () end
---* js ctor
---@return self
function SpriteDisplayData:SpriteDisplayData () end