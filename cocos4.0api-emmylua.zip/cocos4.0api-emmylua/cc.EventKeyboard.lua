
---@class cc.EventKeyboard :cc.Event
local EventKeyboard={ }
cc.EventKeyboard=EventKeyboard




---*  Constructor.<br>
---* param keyCode A given keycode.<br>
---* param isPressed True if the key is pressed.<br>
---* js ctor
---@param keyCode int
---@param isPressed boolean
---@return self
function EventKeyboard:EventKeyboard (keyCode,isPressed) end