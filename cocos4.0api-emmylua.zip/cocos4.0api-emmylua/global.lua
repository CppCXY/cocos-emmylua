
---require emmylua 0.3.36

---@class ccui
ccui={}
---@class cc
cc={}
---@class ccs
ccs={}
---@class ccb
ccb={}
---@class sp
sp={}
---@class cc.ResourceData

---@class int

---@class float

---@class size_table

---@class unsigned_int

---@class vec3_table

---@class array_table

---@class char

---@class vec2_table

---@class ccs.ActionNode

---@class ccs.AnimationInfo

---@class color3b_table

---@class unsigned_char

---@class map_table

---@class rect_table

---@class cc.Animation3DData

---@class cc.BlendFunc

---@class mat4_table

---@class void

---@class cc.TextureAtlas

---@class cc.Bone3D

---@class color4b_table

---@class cc._ccBezierConfig

---@class ccs.ColliderDetector

---@class color4f_table

---@class cc.SkinData

---@class cc.MaterialDatas

---@class cc.NodeDatas

---@class cc.AABB

---@class cc.Viewport

---@class cc.Camer

---@class point_table

---@class unsigned short

---@class color3b_tabl

---@class double

---@class cc.IMEKeyboardNotificationInfo

---@class cc.Value

---@class floa

---@class boo

---@class GLContextAttrs

---@class cc._ttfConfig

---@class cc.FontAtlas

---@class cc.backend.ProgramState

---@class cc.MeshCommand

---@class cc.backend.Buffer

---@class cc.MeshVertexAttrib

---@class vec4_table

---@class cc.MeshIndexData

---@class cc.MeshSkin

---@class cc.Quaternion

---@class cc.OffMeshLinkData

---@class cc.NavMeshAgentParam

---@class cc.AffineTransform

---@class cc.Particle3DAffector

---@class cc.Particle3DRender

---@class cc.Particle3DEmitter

---@class voi

---@class unsigned in

---@class cc.VertexAttribBinding

---@class cc.backend.TextureBacken

---@class btTypedConstraint

---@class btRigidBody

---@class cc.Physics3DRigidBodyDes

---@class btCollisionShape

---@class cpBody

---@class cc.PhysicsMaterial

---@class cc.PhysicsContactData

---@class cc.V3F_C4B_T2F_Quad

---@class cc.TrianglesCommand.Triangles

---@class cc.backend.UniformLocation

---@class cc.backend.Program

---@class cc.backend.TextureBackend

---@class long

---@class cc.PUEmitter

---@class cc.PUListener

---@class cc.PUBehaviour

---@class cc.PUParticle3D

---@class cc.PUObserver

---@class cc.RenderCommand

---@class cc.ScissorRect

---@class cc.MeshComman

---@class cc.backend.ShaderCache

---@class cc.backend.ShaderModule

---@class spTrackEntry

---@class spAnimation

---@class spAtlas

---@class spSkeletonData

---@class spVertexEffect

---@class spSkeleton

---@class cc.TextureCub

---@class cc.ScrollView

---@class cc.Terrain.DetailMap

---@class cc.Terrain.TerrainData

---@class cc.FontDefinition

---@class cc.backend.Texture2DBackend

---@class cc.backend.SamplerDescriptor

---@class cc.backend.TextureDescriptor

---@class cc.backend.SamplerDescripto

---@class cc.backend.TextureCubemapBackend

---@class short

---@class cc.backend.VertexLayout

