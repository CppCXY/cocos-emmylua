
---@class cc.TMXLayerInfo :cc.Ref
local TMXLayerInfo={ }
cc.TMXLayerInfo=TMXLayerInfo




---* 
---@param properties map_table
---@return self
function TMXLayerInfo:setProperties (properties) end
---* 
---@return map_table
function TMXLayerInfo:getProperties () end
---* js ctor
---@return self
function TMXLayerInfo:TMXLayerInfo () end